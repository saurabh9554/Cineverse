import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/* -------------------------------- analytics -------------------------------- */

export const getAdminOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: adminRole } = await context.supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", context.userId)
      .eq("role", "admin")
      .maybeSingle();
    if (!adminRole) throw new Error("Forbidden: admin access required");


    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const since = new Date(Date.now() - 13 * 86400000).toISOString().slice(0, 10);

    const [users, watch, reviews, news, events] = await Promise.all([
      supabaseAdmin.from("profiles").select("id, display_name, username, created_at", { count: "exact" }).order("created_at", { ascending: false }).limit(8),
      supabaseAdmin.from("watchlist").select("movie_id, title", { count: "exact" }).limit(500),
      supabaseAdmin.from("reviews").select("id, movie_id, movie_title, rating, content, created_at", { count: "exact" }).order("created_at", { ascending: false }).limit(10),
      supabaseAdmin.from("news").select("id, title, slug, category, published, published_at", { count: "exact" }).order("created_at", { ascending: false }).limit(20),
      supabaseAdmin.from("analytics_events").select("event_type, created_at").gte("created_at", since).limit(5000),
    ]);

    const dayBuckets = new Map<string, number>();
    for (let i = 13; i >= 0; i--) {
      const key = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      dayBuckets.set(key, 0);
    }
    const typeBuckets = new Map<string, number>();
    for (const event of events.data ?? []) {
      const key = String(event.created_at).slice(0, 10);
      if (dayBuckets.has(key)) dayBuckets.set(key, (dayBuckets.get(key) ?? 0) + 1);
      typeBuckets.set(event.event_type, (typeBuckets.get(event.event_type) ?? 0) + 1);
    }

    const movieCounts = new Map<string, number>();
    for (const row of watch.data ?? []) {
      movieCounts.set(row.title, (movieCounts.get(row.title) ?? 0) + 1);
    }

    return {
      totals: {
        users: users.count ?? 0,
        watchlistItems: watch.count ?? 0,
        reviews: reviews.count ?? 0,
        articles: news.count ?? 0,
        events: events.data?.length ?? 0,
      },
      activity: [...dayBuckets.entries()].map(([date, count]) => ({
        date: date.slice(5),
        count,
      })),
      eventTypes: [...typeBuckets.entries()].map(([type, count]) => ({ type, count })),
      topSaved: [...movieCounts.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, 8)
        .map(([title, count]) => ({ title, count })),
      recentUsers: users.data ?? [],
      recentReviews: reviews.data ?? [],
      articles: news.data ?? [],
    };
  });

/* ---------------------------------- news ----------------------------------- */

const articleSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(3).max(180),
  slug: z
    .string()
    .trim()
    .min(3)
    .max(180)
    .regex(/^[a-z0-9-]+$/, "Slug must be lowercase words separated by hyphens"),
  excerpt: z.string().trim().max(400).default(""),
  content: z.string().trim().max(20000).default(""),
  category: z.string().trim().max(40).default("Industry"),
  coverImageUrl: z.string().trim().max(600).default(""),
  published: z.boolean().default(false),
});

export const saveArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => articleSchema.parse(input))
  .handler(async ({ data, context }) => {
    const payload = {
      title: data.title,
      slug: data.slug,
      excerpt: data.excerpt,
      content: data.content,
      category: data.category,
      cover_image_url: data.coverImageUrl || null,
      published: data.published,
      published_at: data.published ? new Date().toISOString() : null,
      author_id: context.userId,
    };

    const query = data.id
      ? context.supabase.from("news").update(payload).eq("id", data.id)
      : context.supabase.from("news").insert(payload);

    const { error } = await query;
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteArticle = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("news").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
