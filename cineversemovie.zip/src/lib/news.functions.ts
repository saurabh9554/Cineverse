import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { publicSupabase } from "./supabase-public.server";

export type NewsArticle = {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  coverImageUrl: string | null;
  publishedAt: string | null;
};

export const listNews = createServerFn({ method: "GET" }).handler(
  async (): Promise<NewsArticle[]> => {
    const { data, error } = await publicSupabase()
      .from("news")
      .select("id, title, slug, excerpt, content, category, cover_image_url, published_at")
      .eq("published", true)
      .order("published_at", { ascending: false })
      .limit(30);

    if (error) {
      console.error("[news] read failed", error.message);
      return [];
    }

    return (data ?? []).map((row) => ({
      id: row.id,
      title: row.title,
      slug: row.slug,
      excerpt: row.excerpt,
      content: row.content,
      category: row.category,
      coverImageUrl: row.cover_image_url,
      publishedAt: row.published_at,
    }));
  },
);

export const getNewsArticle = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string }) =>
    z.object({ slug: z.string().min(1).max(200) }).parse(input),
  )
  .handler(async ({ data }): Promise<NewsArticle | null> => {
    const { data: row, error } = await publicSupabase()
      .from("news")
      .select("id, title, slug, excerpt, content, category, cover_image_url, published_at")
      .eq("slug", data.slug)
      .eq("published", true)
      .maybeSingle();

    if (error || !row) return null;
    return {
      id: row.id,
      title: row.title,
      slug: row.slug,
      excerpt: row.excerpt,
      content: row.content,
      category: row.category,
      coverImageUrl: row.cover_image_url,
      publishedAt: row.published_at,
    };
  });
