import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { publicSupabase } from "./supabase-public.server";

/** Fire-and-forget analytics event recording (anonymous or signed-in). */
export const trackEvent = createServerFn({ method: "POST" })
  .inputValidator((input: { eventType: string; movieId?: number | null; path?: string }) =>
    z
      .object({
        eventType: z.string().trim().min(1).max(60),
        movieId: z.number().int().positive().nullable().default(null),
        path: z.string().trim().max(300).default(""),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { error } = await publicSupabase().from("analytics_events").insert({
      event_type: data.eventType,
      movie_id: data.movieId,
      path: data.path || null,
    });
    if (error) console.error("[analytics] insert failed", error.message);
    return { ok: true };
  });
