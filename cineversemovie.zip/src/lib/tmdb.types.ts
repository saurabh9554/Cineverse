/** Shared, client-safe TMDB DTO types. No server-only imports here. */

export type MovieSummary = {
  id: number;
  title: string;
  overview: string;
  posterPath: string | null;
  backdropPath: string | null;
  releaseDate: string | null;
  voteAverage: number;
  voteCount: number;
  genreIds: number[];
  popularity: number;
};

export type PagedMovies = {
  page: number;
  totalPages: number;
  totalResults: number;
  results: MovieSummary[];
};

export type Genre = { id: number; name: string };

export type CastMember = {
  id: number;
  name: string;
  character: string;
  profilePath: string | null;
};

export type CrewMember = { id: number; name: string; job: string };

export type Video = {
  key: string;
  name: string;
  site: string;
  type: string;
  official: boolean;
};

export type OmdbMeta = {
  imdbRating: string | null;
  imdbVotes: string | null;
  metascore: string | null;
  rated: string | null;
  awards: string | null;
  boxOffice: string | null;
  director: string | null;
  writer: string | null;
  ratings: { source: string; value: string }[];
};

export type WatchProvider = { id: number; name: string; logoPath: string | null };

export type WatchProviders = {
  region: string;
  link: string | null;
  flatrate: WatchProvider[];
  rent: WatchProvider[];
  buy: WatchProvider[];
};

export type CollectionSummary = {
  id: number;
  name: string;
  posterPath: string | null;
  backdropPath: string | null;
};

export type CollectionDetail = CollectionSummary & {
  overview: string;
  parts: MovieSummary[];
};

export type RatingSource = {
  source: string;
  value: string;
  /** Normalised 0-100 score, when it can be derived. */
  percent: number | null;
};

export type ReleaseEntry = {
  /** TMDB release type: 1 Premiere, 2 Theatrical (limited), 3 Theatrical, 4 Digital, 5 Physical, 6 TV */
  type: number;
  date: string;
  certification: string | null;
  note: string | null;
};

export type RegionalRelease = {
  country: string;
  countryName: string;
  entries: ReleaseEntry[];
};

export type MovieDetail = MovieSummary & {
  tagline: string | null;
  runtime: number | null;
  status: string | null;
  budget: number;
  revenue: number;
  homepage: string | null;
  imdbId: string | null;
  originalLanguage: string;
  spokenLanguages: string[];
  productionCountries: string[];
  genres: Genre[];
  keywords: string[];
  cast: CastMember[];
  crew: CrewMember[];
  trailer: Video | null;
  videos: Video[];
  images: string[];
  similar: MovieSummary[];
  recommendations: MovieSummary[];
  collection: CollectionDetail | null;
  providers: WatchProviders | null;
  omdb: OmdbMeta | null;
  releases: RegionalRelease[];
};

export type PersonCredit = MovieSummary & { role: string };

export type PersonDetail = {
  id: number;
  name: string;
  biography: string;
  birthday: string | null;
  deathday: string | null;
  placeOfBirth: string | null;
  knownFor: string | null;
  profilePath: string | null;
  homepage: string | null;
  imdbId: string | null;
  acting: PersonCredit[];
  directing: PersonCredit[];
};


export type DiscoverFilters = {
  page?: number;
  genres?: number[];
  yearFrom?: number;
  yearTo?: number;
  minRating?: number;
  minVotes?: number;
  sortBy?: string;
  query?: string;
  language?: string;
};

export const SORT_OPTIONS = [
  { value: "popularity.desc", label: "Most popular" },
  { value: "vote_average.desc", label: "Highest rated" },
  { value: "primary_release_date.desc", label: "Newest first" },
  { value: "primary_release_date.asc", label: "Oldest first" },
  { value: "revenue.desc", label: "Biggest box office" },
  { value: "title.asc", label: "Title (A–Z)" },
] as const;

export const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";

export function posterUrl(path: string | null, size: "w185" | "w342" | "w500" = "w342") {
  return path ? `${TMDB_IMAGE_BASE}/${size}${path}` : null;
}

export function backdropUrl(path: string | null, size: "w780" | "w1280" | "original" = "w1280") {
  return path ? `${TMDB_IMAGE_BASE}/${size}${path}` : null;
}

export function profileUrl(path: string | null) {
  return path ? `${TMDB_IMAGE_BASE}/w185${path}` : null;
}

export function releaseYear(date: string | null) {
  return date ? date.slice(0, 4) : "—";
}

export function formatRuntime(minutes: number | null) {
  if (!minutes) return "—";
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export function formatCurrency(value: number) {
  if (!value) return "—";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value);
}

/* ---------------------------------- web series ---------------------------------- */

export type TvSeason = {
  id: number;
  name: string;
  seasonNumber: number;
  episodeCount: number;
  airDate: string | null;
  posterPath: string | null;
  overview: string;
};

export type TvNetwork = { id: number; name: string; logoPath: string | null };

export type TvDetail = MovieSummary & {
  tagline: string | null;
  status: string | null;
  type: string | null;
  firstAirDate: string | null;
  lastAirDate: string | null;
  numberOfSeasons: number;
  numberOfEpisodes: number;
  episodeRuntime: number | null;
  inProduction: boolean;
  homepage: string | null;
  imdbId: string | null;
  originalLanguage: string;
  spokenLanguages: string[];
  productionCountries: string[];
  networks: TvNetwork[];
  creators: CastMember[];
  genres: Genre[];
  keywords: string[];
  cast: CastMember[];
  crew: CrewMember[];
  seasons: TvSeason[];
  trailer: Video | null;
  videos: Video[];
  images: string[];
  similar: MovieSummary[];
  recommendations: MovieSummary[];
  providers: WatchProviders | null;
  omdb: OmdbMeta | null;
};

export function formatEpisodeRuntime(minutes: number | null) {
  return minutes ? `${minutes}m / ep` : "—";
}

export type EpisodeSummary = {
  id: number;
  name: string;
  overview: string;
  episodeNumber: number;
  seasonNumber: number;
  airDate: string | null;
  runtime: number | null;
  stillPath: string | null;
  voteAverage: number;
  voteCount: number;
};

export type SeasonDetail = {
  seriesId: number;
  seriesTitle: string;
  seriesPosterPath: string | null;
  seriesBackdropPath: string | null;
  id: number;
  name: string;
  overview: string;
  seasonNumber: number;
  airDate: string | null;
  posterPath: string | null;
  episodes: EpisodeSummary[];
};

export type EpisodeDetail = EpisodeSummary & {
  seriesId: number;
  seriesTitle: string;
  seriesBackdropPath: string | null;
  seasonName: string;
  guestStars: CastMember[];
  cast: CastMember[];
  crew: CrewMember[];
  videos: Video[];
  trailer: Video | null;
  images: string[];
  previousEpisode: number | null;
  nextEpisode: number | null;
  totalEpisodes: number;
};

/* ---------------------------------- releases ---------------------------------- */

export const RELEASE_TYPE_LABELS: Record<number, string> = {
  1: "Premiere",
  2: "Theatrical (limited)",
  3: "Theatrical",
  4: "Digital / OTT",
  5: "Physical",
  6: "TV",
};

/** Regions surfaced first, India always leading. */
export const PRIORITY_RELEASE_REGIONS = ["IN", "US", "GB", "AE", "AU", "CA"] as const;

export function countryName(code: string) {
  try {
    return new Intl.DisplayNames(["en"], { type: "region" }).of(code) ?? code;
  } catch {
    return code;
  }
}

export function formatReleaseDate(value: string) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

/* ----------------------------------- awards ----------------------------------- */

export type AwardsSummary = {
  raw: string;
  oscarWins: number;
  oscarNominations: number;
  wins: number;
  nominations: number;
  highlights: string[];
};

/** Parses the OMDb awards string (the only licensed awards source available). */
export function parseAwards(raw: string | null | undefined): AwardsSummary | null {
  if (!raw || raw === "N/A") return null;
  const num = (re: RegExp) => {
    const m = raw.match(re);
    return m ? Number(m[1]) : 0;
  };
  const oscarWins = num(/Won (\d+) Oscar/i);
  const oscarNominations = num(/Nominated for (\d+) Oscar/i);
  const wins = num(/(\d+) wins?/i) + (oscarWins && !/\d+ wins?/i.test(raw) ? oscarWins : 0);
  const nominations =
    num(/(\d+) nominations?/i) + (oscarNominations && !/\d+ nominations?/i.test(raw) ? oscarNominations : 0);
  const highlights = raw
    .split(/\.\s*|&\s*/)
    .map((part) => part.trim())
    .filter(Boolean);
  return { raw, oscarWins, oscarNominations, wins, nominations, highlights };
}

export function stillUrl(path: string | null, size: "w300" | "w780" = "w300") {
  return path ? `${TMDB_IMAGE_BASE}/${size}${path}` : null;
}
