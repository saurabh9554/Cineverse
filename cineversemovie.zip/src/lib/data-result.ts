/** Client-safe wrapper describing success/failure of a data read. */
export type DataResult<T> =
  | { ok: true; data: T }
  | { ok: false; reason: "not_configured" | "error"; message: string };

export function ok<T>(data: T): DataResult<T> {
  return { ok: true, data };
}
