/**
 * Server-only TMDB + OMDb data layer.
 * Never import this from components — only from *.functions.ts handlers.
 */
import type {
  CastMember,
  CollectionDetail,
  CrewMember,
  DiscoverFilters,
  Genre,
  MovieDetail,
  MovieSummary,
  OmdbMeta,
  PagedMovies,
  PersonCredit,
  PersonDetail,
  Video,
  WatchProvider,
  WatchProviders,
} from "./tmdb.types";
import { countryName, PRIORITY_RELEASE_REGIONS } from "./tmdb.types";
import type { RegionalRelease } from "./tmdb.types";


const TMDB_BASE = "https://api.themoviedb.org/3";
const OMDB_BASE = "https://www.omdbapi.com/";

export class TmdbNotConfiguredError extends Error {
  constructor() {
    super("TMDB_API_KEY is not configured");
    this.name = "TmdbNotConfiguredError";
  }
}

function tmdbKey() {
  const key = process.env.TMDB_API_KEY;
  if (!key) throw new TmdbNotConfiguredError();
  return key;
}

async function tmdb<T>(path: string, params: Record<string, string | number | undefined> = {}) {
  const url = new URL(`${TMDB_BASE}${path}`);
  url.searchParams.set("api_key", tmdbKey());
  url.searchParams.set("language", "en-US");
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== "") url.searchParams.set(k, String(v));
  }

  const res = await fetch(url, { headers: { accept: "application/json" } });
  if (!res.ok) {
    const body = await res.text();
    console.error(`[TMDB] ${path} failed [${res.status}]: ${body}`);
    throw new Error(`Movie service request failed (${res.status})`);
  }
  return (await res.json()) as T;
}

/* ---------------------------------- mappers --------------------------------- */

type RawMovie = {
  id: number;
  title?: string;
  name?: string;
  overview?: string;
  poster_path?: string | null;
  backdrop_path?: string | null;
  release_date?: string | null;
  first_air_date?: string | null;
  vote_average?: number;
  vote_count?: number;
  genre_ids?: number[];
  genres?: Genre[];
  popularity?: number;
};

export function toSummary(raw: RawMovie): MovieSummary {
  return {
    id: raw.id,
    title: raw.title ?? raw.name ?? "Untitled",
    overview: raw.overview ?? "",
    posterPath: raw.poster_path ?? null,
    backdropPath: raw.backdrop_path ?? null,
    releaseDate: raw.release_date || raw.first_air_date || null,
    voteAverage: Number(raw.vote_average ?? 0),
    voteCount: Number(raw.vote_count ?? 0),
    genreIds: raw.genre_ids ?? raw.genres?.map((g) => g.id) ?? [],
    popularity: Number(raw.popularity ?? 0),
  };
}

function toPaged(raw: {
  page: number;
  total_pages: number;
  total_results: number;
  results: RawMovie[];
}): PagedMovies {
  return {
    page: raw.page,
    totalPages: Math.min(raw.total_pages, 500),
    totalResults: raw.total_results,
    results: (raw.results ?? []).map(toSummary),
  };
}

/* ----------------------------------- reads ---------------------------------- */

export type ListCategory = "popular" | "top_rated" | "upcoming" | "now_playing";

export async function fetchList(category: ListCategory, page = 1) {
  return toPaged(await tmdb(`/movie/${category}`, { page }));
}

export async function fetchTrending(window: "day" | "week" = "week", page = 1) {
  return toPaged(await tmdb(`/trending/movie/${window}`, { page }));
}

export async function fetchGenres(): Promise<Genre[]> {
  const data = await tmdb<{ genres: Genre[] }>("/genre/movie/list");
  return data.genres;
}

export async function fetchDiscover(filters: DiscoverFilters): Promise<PagedMovies> {
  return toPaged(
    await tmdb("/discover/movie", {
      page: filters.page ?? 1,
      sort_by: filters.sortBy ?? "popularity.desc",
      with_genres: filters.genres?.length ? filters.genres.join(",") : undefined,
      "primary_release_date.gte": filters.yearFrom ? `${filters.yearFrom}-01-01` : undefined,
      "primary_release_date.lte": filters.yearTo ? `${filters.yearTo}-12-31` : undefined,
      "vote_average.gte": filters.minRating || undefined,
      "vote_count.gte": filters.minVotes ?? 50,
      with_original_language: filters.language || undefined,
      include_adult: "false",
    }),
  );
}

export async function fetchSearch(query: string, page = 1): Promise<PagedMovies> {
  if (!query.trim()) {
    return { page: 1, totalPages: 0, totalResults: 0, results: [] };
  }
  return toPaged(await tmdb("/search/movie", { query, page, include_adult: "false" }));
}

async function fetchOmdb(imdbId: string | null): Promise<OmdbMeta | null> {
  const key = process.env.OMDB_API_KEY;
  if (!key || !imdbId) return null;
  try {
    const url = new URL(OMDB_BASE);
    url.searchParams.set("apikey", key);
    url.searchParams.set("i", imdbId);
    const res = await fetch(url);
    if (!res.ok) {
      console.error(`[OMDb] failed [${res.status}]: ${await res.text()}`);
      return null;
    }
    const raw = (await res.json()) as Record<string, unknown> & {
      Ratings?: { Source: string; Value: string }[];
    };
    if (raw.Response === "False") return null;
    const str = (v: unknown) => (typeof v === "string" && v !== "N/A" ? v : null);
    return {
      imdbRating: str(raw.imdbRating),
      imdbVotes: str(raw.imdbVotes),
      metascore: str(raw.Metascore),
      rated: str(raw.Rated),
      awards: str(raw.Awards),
      boxOffice: str(raw.BoxOffice),
      director: str(raw.Director),
      writer: str(raw.Writer),
      ratings: (raw.Ratings ?? []).map((r) => ({ source: r.Source, value: r.Value })),
    };
  } catch (error) {
    console.error("[OMDb] request error", error);
    return null;
  }
}

type RawProvider = { provider_id: number; provider_name: string; logo_path?: string | null };

type RawDetail = RawMovie & {
  tagline?: string;
  runtime?: number | null;
  status?: string;
  budget?: number;
  revenue?: number;
  homepage?: string | null;
  imdb_id?: string | null;
  original_language?: string;
  spoken_languages?: { english_name?: string; name?: string }[];
  production_countries?: { name: string }[];
  belongs_to_collection?: { id: number } | null;
  keywords?: { keywords?: { id: number; name: string }[] };
  images?: { backdrops?: { file_path: string }[] };
  "watch/providers"?: {
    results?: Record<
      string,
      { link?: string; flatrate?: RawProvider[]; rent?: RawProvider[]; buy?: RawProvider[] }
    >;
  };
  credits?: {
    cast?: { id: number; name: string; character?: string; profile_path?: string | null }[];
    crew?: { id: number; name: string; job: string }[];
  };
  videos?: { results?: { key: string; name: string; site: string; type: string; official: boolean }[] };
  similar?: { results?: RawMovie[] };
  recommendations?: { results?: RawMovie[] };
  release_dates?: {
    results?: {
      iso_3166_1: string;
      release_dates?: {
        type?: number;
        release_date?: string;
        certification?: string;
        note?: string;
      }[];
    }[];
  };
};

/** Groups TMDB regional release dates, always surfacing India and other key markets first. */
function mapReleases(
  raw: {
    iso_3166_1: string;
    release_dates?: { type?: number; release_date?: string; certification?: string; note?: string }[];
  }[],
): RegionalRelease[] {
  const grouped: RegionalRelease[] = raw
    .map((region) => ({
      country: region.iso_3166_1,
      countryName: countryName(region.iso_3166_1),
      entries: (region.release_dates ?? [])
        .filter((entry) => Boolean(entry.release_date))
        .map((entry) => ({
          type: entry.type ?? 3,
          date: entry.release_date!.slice(0, 10),
          certification: entry.certification || null,
          note: entry.note || null,
        }))
        .sort((a, b) => a.date.localeCompare(b.date)),
    }))
    .filter((region) => region.entries.length > 0);

  const rank = (code: string) => {
    const index = PRIORITY_RELEASE_REGIONS.indexOf(code as (typeof PRIORITY_RELEASE_REGIONS)[number]);
    return index === -1 ? PRIORITY_RELEASE_REGIONS.length : index;
  };

  return grouped
    .sort((a, b) => rank(a.country) - rank(b.country) || a.countryName.localeCompare(b.countryName))
    .slice(0, 12);
}

function toProvider(raw: RawProvider): WatchProvider {
  return { id: raw.provider_id, name: raw.provider_name, logoPath: raw.logo_path ?? null };
}

/** Picks the best available streaming region — India first, then US, then anything. */
function pickProviders(

  results: Record<
    string,
    { link?: string; flatrate?: RawProvider[]; rent?: RawProvider[]; buy?: RawProvider[] }
  > = {},
): WatchProviders | null {
  const region = ["IN", "US", "GB", ...Object.keys(results)].find((code) => results[code]);
  if (!region) return null;
  const entry = results[region];
  const providers: WatchProviders = {
    region,
    link: entry.link ?? null,
    flatrate: (entry.flatrate ?? []).map(toProvider),
    rent: (entry.rent ?? []).map(toProvider),
    buy: (entry.buy ?? []).map(toProvider),
  };
  return providers.flatrate.length || providers.rent.length || providers.buy.length
    ? providers
    : null;
}

export async function fetchCollection(id: number): Promise<CollectionDetail> {
  const raw = await tmdb<{
    id: number;
    name: string;
    overview?: string;
    poster_path?: string | null;
    backdrop_path?: string | null;
    parts?: RawMovie[];
  }>(`/collection/${id}`);

  return {
    id: raw.id,
    name: raw.name,
    overview: raw.overview ?? "",
    posterPath: raw.poster_path ?? null,
    backdropPath: raw.backdrop_path ?? null,
    parts: (raw.parts ?? [])
      .map(toSummary)
      .sort((a, b) => (a.releaseDate ?? "9999").localeCompare(b.releaseDate ?? "9999")),
  };
}

export async function fetchPerson(id: number): Promise<PersonDetail> {
  const raw = await tmdb<{
    id: number;
    name: string;
    biography?: string;
    birthday?: string | null;
    deathday?: string | null;
    place_of_birth?: string | null;
    known_for_department?: string | null;
    profile_path?: string | null;
    homepage?: string | null;
    imdb_id?: string | null;
    movie_credits?: {
      cast?: (RawMovie & { character?: string })[];
      crew?: (RawMovie & { job?: string })[];
    };
  }>(`/person/${id}`, { append_to_response: "movie_credits" });

  const byPopularity = (a: PersonCredit, b: PersonCredit) => b.popularity - a.popularity;

  const acting: PersonCredit[] = (raw.movie_credits?.cast ?? [])
    .map((c) => ({ ...toSummary(c), role: c.character ?? "" }))
    .sort(byPopularity)
    .slice(0, 24);

  const directing: PersonCredit[] = (raw.movie_credits?.crew ?? [])
    .filter((c) => ["Director", "Writer", "Screenplay", "Producer"].includes(c.job ?? ""))
    .map((c) => ({ ...toSummary(c), role: c.job ?? "" }))
    .sort(byPopularity)
    .slice(0, 24);

  return {
    id: raw.id,
    name: raw.name,
    biography: raw.biography ?? "",
    birthday: raw.birthday ?? null,
    deathday: raw.deathday ?? null,
    placeOfBirth: raw.place_of_birth ?? null,
    knownFor: raw.known_for_department ?? null,
    profilePath: raw.profile_path ?? null,
    homepage: raw.homepage || null,
    imdbId: raw.imdb_id || null,
    acting,
    directing,
  };
}

export async function fetchMovie(id: number): Promise<MovieDetail> {
  const raw = await tmdb<RawDetail>(`/movie/${id}`, {
    append_to_response:
      "credits,videos,similar,recommendations,keywords,images,release_dates,watch/providers",
    include_image_language: "en,null",
  });

  const videos: Video[] = (raw.videos?.results ?? []).filter((v) => v.site === "YouTube");
  const trailer =
    videos.find((v) => v.type === "Trailer" && v.official) ??
    videos.find((v) => v.type === "Trailer") ??
    videos.find((v) => v.type === "Teaser") ??
    null;

  const cast: CastMember[] = (raw.credits?.cast ?? []).slice(0, 18).map((c) => ({
    id: c.id,
    name: c.name,
    character: c.character ?? "",
    profilePath: c.profile_path ?? null,
  }));

  const crew: CrewMember[] = (raw.credits?.crew ?? [])
    .filter((c) => ["Director", "Screenplay", "Writer", "Original Music Composer"].includes(c.job))
    .slice(0, 8)
    .map((c) => ({ id: c.id, name: c.name, job: c.job }));

  const [omdb, collection] = await Promise.all([
    fetchOmdb(raw.imdb_id ?? null),
    raw.belongs_to_collection?.id
      ? fetchCollection(raw.belongs_to_collection.id).catch(() => null)
      : Promise.resolve(null),
  ]);

  return {
    ...toSummary(raw),
    tagline: raw.tagline || null,
    runtime: raw.runtime ?? null,
    status: raw.status ?? null,
    budget: raw.budget ?? 0,
    revenue: raw.revenue ?? 0,
    homepage: raw.homepage || null,
    imdbId: raw.imdb_id ?? null,
    originalLanguage: raw.original_language ?? "en",
    spokenLanguages: (raw.spoken_languages ?? [])
      .map((l) => l.english_name ?? l.name ?? "")
      .filter(Boolean),
    productionCountries: (raw.production_countries ?? []).map((c) => c.name),
    genres: raw.genres ?? [],
    keywords: (raw.keywords?.keywords ?? []).slice(0, 12).map((k) => k.name),
    cast,
    crew,
    trailer,
    videos: videos.slice(0, 8),
    images: (raw.images?.backdrops ?? []).slice(0, 12).map((b) => b.file_path),
    similar: (raw.similar?.results ?? []).slice(0, 12).map(toSummary),
    recommendations: (raw.recommendations?.results ?? []).slice(0, 12).map(toSummary),
    collection,
    providers: pickProviders(raw["watch/providers"]?.results ?? {}),
    omdb,
    releases: mapReleases(raw.release_dates?.results ?? []),
  };
}


/* --------------------------- safe result wrappers --------------------------- */

import type { DataResult } from "./data-result";

export async function safe<T>(fn: () => Promise<T>): Promise<DataResult<T>> {
  try {
    return { ok: true, data: await fn() };
  } catch (error) {
    if (error instanceof TmdbNotConfiguredError) {
      return {
        ok: false,
        reason: "not_configured",
        message: "The movie data service is not connected yet.",
      };
    }
    console.error("[data] read failed", error);
    return {
      ok: false,
      reason: "error",
      message: error instanceof Error ? error.message : "Unexpected error",
    };
  }
}

export type HomePayload = {
  hero: MovieSummary[];
  trending: MovieSummary[];
  popular: MovieSummary[];
  topRated: MovieSummary[];
  upcoming: MovieSummary[];
  nowPlaying: MovieSummary[];
  genres: Genre[];
};

export async function fetchHome(): Promise<HomePayload> {
  const [trending, popular, topRated, upcoming, nowPlaying, genres] = await Promise.all([
    fetchTrending("week"),
    fetchList("popular"),
    fetchList("top_rated"),
    fetchList("upcoming"),
    fetchList("now_playing"),
    fetchGenres(),
  ]);

  return {
    hero: trending.results.filter((m) => m.backdropPath).slice(0, 5),
    trending: trending.results.slice(0, 18),
    popular: popular.results.slice(0, 18),
    topRated: topRated.results.slice(0, 18),
    upcoming: upcoming.results.slice(0, 18),
    nowPlaying: nowPlaying.results.slice(0, 18),
    genres,
  };
}

/* ------------------------------ industry hubs ------------------------------ */

export type IndustryPayload = {
  hero: MovieSummary[];
  trending: MovieSummary[];
  topRated: MovieSummary[];
  upcoming: MovieSummary[];
  classics: MovieSummary[];
};

export async function fetchIndustry(language: string): Promise<IndustryPayload> {
  const today = new Date().toISOString().slice(0, 10);
  const lastYear = new Date(Date.now() - 400 * 86400000).toISOString().slice(0, 10);

  const base = { with_original_language: language, include_adult: "false" };

  const [trending, topRated, upcoming, classics] = await Promise.all([
    tmdb("/discover/movie", {
      ...base,
      sort_by: "popularity.desc",
      "primary_release_date.gte": lastYear,
    }),
    tmdb("/discover/movie", { ...base, sort_by: "vote_average.desc", "vote_count.gte": 150 }),
    tmdb("/discover/movie", {
      ...base,
      sort_by: "primary_release_date.asc",
      "primary_release_date.gte": today,
      "vote_count.gte": 0,
    }),
    tmdb("/discover/movie", {
      ...base,
      sort_by: "vote_average.desc",
      "vote_count.gte": 100,
      "primary_release_date.lte": "2010-12-31",
    }),
  ] as Promise<{ page: number; total_pages: number; total_results: number; results: RawMovie[] }>[]);

  const trend = toPaged(trending);

  return {
    hero: trend.results.filter((m) => m.backdropPath).slice(0, 5),
    trending: trend.results.slice(0, 18),
    topRated: toPaged(topRated).results.slice(0, 18),
    upcoming: toPaged(upcoming).results.slice(0, 18),
    classics: toPaged(classics).results.slice(0, 18),
  };
}


/* -------------------------------- web series -------------------------------- */

import type { TvDetail, TvNetwork, TvSeason } from "./tmdb.types";

export type TvCategory = "popular" | "top_rated" | "on_the_air" | "airing_today";

export async function fetchTvList(category: TvCategory, page = 1): Promise<PagedMovies> {
  return toPaged(await tmdb(`/tv/${category}`, { page }));
}

export async function fetchTvTrending(window: "day" | "week" = "week", page = 1) {
  return toPaged(await tmdb(`/trending/tv/${window}`, { page }));
}

export async function fetchTvGenres(): Promise<Genre[]> {
  const data = await tmdb<{ genres: Genre[] }>("/genre/tv/list");
  return data.genres;
}

export async function fetchTvSearch(query: string, page = 1): Promise<PagedMovies> {
  if (!query.trim()) return { page: 1, totalPages: 0, totalResults: 0, results: [] };
  return toPaged(await tmdb("/search/tv", { query, page, include_adult: "false" }));
}

export async function fetchTvDiscover(filters: DiscoverFilters): Promise<PagedMovies> {
  return toPaged(
    await tmdb("/discover/tv", {
      page: filters.page ?? 1,
      sort_by: filters.sortBy ?? "popularity.desc",
      with_genres: filters.genres?.length ? filters.genres.join(",") : undefined,
      "first_air_date.gte": filters.yearFrom ? `${filters.yearFrom}-01-01` : undefined,
      "first_air_date.lte": filters.yearTo ? `${filters.yearTo}-12-31` : undefined,
      "vote_average.gte": filters.minRating || undefined,
      "vote_count.gte": filters.minVotes ?? 50,
      with_original_language: filters.language || undefined,
      include_adult: "false",
    }),
  );
}

export type SeriesHubPayload = {
  hero: MovieSummary[];
  trending: MovieSummary[];
  popular: MovieSummary[];
  topRated: MovieSummary[];
  onTheAir: MovieSummary[];
  airingToday: MovieSummary[];
  indian: MovieSummary[];
  genres: Genre[];
};

export async function fetchSeriesHub(): Promise<SeriesHubPayload> {
  const [trending, popular, topRated, onTheAir, airingToday, indian, genres] = await Promise.all([
    fetchTvTrending("week"),
    fetchTvList("popular"),
    fetchTvList("top_rated"),
    fetchTvList("on_the_air"),
    fetchTvList("airing_today"),
    fetchTvDiscover({ language: "hi", sortBy: "popularity.desc", minVotes: 10 }),
    fetchTvGenres(),
  ]);

  return {
    hero: trending.results.filter((s) => s.backdropPath).slice(0, 5),
    trending: trending.results.slice(0, 18),
    popular: popular.results.slice(0, 18),
    topRated: topRated.results.slice(0, 18),
    onTheAir: onTheAir.results.slice(0, 18),
    airingToday: airingToday.results.slice(0, 18),
    indian: indian.results.slice(0, 18),
    genres,
  };
}

type RawTvDetail = RawMovie & {
  tagline?: string;
  status?: string;
  type?: string;
  last_air_date?: string | null;
  number_of_seasons?: number;
  number_of_episodes?: number;
  episode_run_time?: number[];
  in_production?: boolean;
  homepage?: string | null;
  original_language?: string;
  spoken_languages?: { english_name?: string; name?: string }[];
  production_countries?: { name: string }[];
  networks?: { id: number; name: string; logo_path?: string | null }[];
  created_by?: { id: number; name: string; profile_path?: string | null }[];
  seasons?: {
    id: number;
    name: string;
    season_number: number;
    episode_count?: number;
    air_date?: string | null;
    poster_path?: string | null;
    overview?: string;
  }[];
  external_ids?: { imdb_id?: string | null };
  keywords?: { results?: { id: number; name: string }[] };
  images?: { backdrops?: { file_path: string }[] };
  "watch/providers"?: {
    results?: Record<
      string,
      { link?: string; flatrate?: RawProvider[]; rent?: RawProvider[]; buy?: RawProvider[] }
    >;
  };
  aggregate_credits?: {
    cast?: {
      id: number;
      name: string;
      profile_path?: string | null;
      roles?: { character?: string }[];
    }[];
    crew?: { id: number; name: string; job?: string; jobs?: { job?: string }[] }[];
  };
  videos?: { results?: { key: string; name: string; site: string; type: string; official: boolean }[] };
  similar?: { results?: RawMovie[] };
  recommendations?: { results?: RawMovie[] };
};

export async function fetchTv(id: number): Promise<TvDetail> {
  const raw = await tmdb<RawTvDetail>(`/tv/${id}`, {
    append_to_response:
      "aggregate_credits,videos,similar,recommendations,keywords,images,external_ids,watch/providers",
    include_image_language: "en,null",
  });

  const videos: Video[] = (raw.videos?.results ?? []).filter((v) => v.site === "YouTube");
  const trailer =
    videos.find((v) => v.type === "Trailer" && v.official) ??
    videos.find((v) => v.type === "Trailer") ??
    videos.find((v) => v.type === "Teaser") ??
    null;

  const cast: CastMember[] = (raw.aggregate_credits?.cast ?? []).slice(0, 18).map((c) => ({
    id: c.id,
    name: c.name,
    character: c.roles?.[0]?.character ?? "",
    profilePath: c.profile_path ?? null,
  }));

  const crew: CrewMember[] = (raw.aggregate_credits?.crew ?? [])
    .map((c) => ({ id: c.id, name: c.name, job: c.job ?? c.jobs?.[0]?.job ?? "" }))
    .filter((c) => ["Director", "Writer", "Producer", "Executive Producer"].includes(c.job))
    .slice(0, 8);

  const networks: TvNetwork[] = (raw.networks ?? []).map((n) => ({
    id: n.id,
    name: n.name,
    logoPath: n.logo_path ?? null,
  }));

  const seasons: TvSeason[] = (raw.seasons ?? [])
    .filter((s) => s.season_number > 0)
    .map((s) => ({
      id: s.id,
      name: s.name,
      seasonNumber: s.season_number,
      episodeCount: s.episode_count ?? 0,
      airDate: s.air_date || null,
      posterPath: s.poster_path ?? null,
      overview: s.overview ?? "",
    }));

  const imdbId = raw.external_ids?.imdb_id || null;
  const omdb = await fetchOmdb(imdbId);

  return {
    ...toSummary(raw),
    tagline: raw.tagline || null,
    status: raw.status ?? null,
    type: raw.type ?? null,
    firstAirDate: raw.first_air_date || null,
    lastAirDate: raw.last_air_date || null,
    numberOfSeasons: raw.number_of_seasons ?? seasons.length,
    numberOfEpisodes: raw.number_of_episodes ?? 0,
    episodeRuntime: raw.episode_run_time?.[0] ?? null,
    inProduction: Boolean(raw.in_production),
    homepage: raw.homepage || null,
    imdbId,
    originalLanguage: raw.original_language ?? "en",
    spokenLanguages: (raw.spoken_languages ?? [])
      .map((l) => l.english_name ?? l.name ?? "")
      .filter(Boolean),
    productionCountries: (raw.production_countries ?? []).map((c) => c.name),
    networks,
    creators: (raw.created_by ?? []).map((c) => ({
      id: c.id,
      name: c.name,
      character: "Creator",
      profilePath: c.profile_path ?? null,
    })),
    genres: raw.genres ?? [],
    keywords: (raw.keywords?.results ?? []).slice(0, 12).map((k) => k.name),
    cast,
    crew,
    seasons,
    trailer,
    videos: videos.slice(0, 8),
    images: (raw.images?.backdrops ?? []).slice(0, 12).map((b) => b.file_path),
    similar: (raw.similar?.results ?? []).slice(0, 12).map(toSummary),
    recommendations: (raw.recommendations?.results ?? []).slice(0, 12).map(toSummary),
    providers: pickProviders(raw["watch/providers"]?.results ?? {}),
    omdb,
  };
}

/* ------------------------------ seasons & episodes ------------------------------ */

import type { EpisodeDetail, EpisodeSummary, SeasonDetail } from "./tmdb.types";

type RawEpisode = {
  id: number;
  name?: string;
  overview?: string;
  episode_number: number;
  season_number: number;
  air_date?: string | null;
  runtime?: number | null;
  still_path?: string | null;
  vote_average?: number;
  vote_count?: number;
};

function toEpisode(raw: RawEpisode): EpisodeSummary {
  return {
    id: raw.id,
    name: raw.name || `Episode ${raw.episode_number}`,
    overview: raw.overview ?? "",
    episodeNumber: raw.episode_number,
    seasonNumber: raw.season_number,
    airDate: raw.air_date || null,
    runtime: raw.runtime ?? null,
    stillPath: raw.still_path ?? null,
    voteAverage: Number(raw.vote_average ?? 0),
    voteCount: Number(raw.vote_count ?? 0),
  };
}

export async function fetchSeason(seriesId: number, seasonNumber: number): Promise<SeasonDetail> {
  const [series, season] = await Promise.all([
    tmdb<RawTvDetail>(`/tv/${seriesId}`),
    tmdb<{
      id: number;
      name?: string;
      overview?: string;
      season_number: number;
      air_date?: string | null;
      poster_path?: string | null;
      episodes?: RawEpisode[];
    }>(`/tv/${seriesId}/season/${seasonNumber}`),
  ]);

  return {
    seriesId,
    seriesTitle: series.name ?? series.title ?? "Series",
    seriesPosterPath: series.poster_path ?? null,
    seriesBackdropPath: series.backdrop_path ?? null,
    id: season.id,
    name: season.name || `Season ${seasonNumber}`,
    overview: season.overview ?? "",
    seasonNumber: season.season_number ?? seasonNumber,
    airDate: season.air_date || null,
    posterPath: season.poster_path ?? null,
    episodes: (season.episodes ?? []).map(toEpisode),
  };
}

export async function fetchEpisode(
  seriesId: number,
  seasonNumber: number,
  episodeNumber: number,
): Promise<EpisodeDetail> {
  const [series, season, episode] = await Promise.all([
    tmdb<RawTvDetail>(`/tv/${seriesId}`),
    tmdb<{ name?: string; episodes?: RawEpisode[] }>(`/tv/${seriesId}/season/${seasonNumber}`),
    tmdb<
      RawEpisode & {
        credits?: {
          cast?: { id: number; name: string; character?: string; profile_path?: string | null }[];
          guest_stars?: {
            id: number;
            name: string;
            character?: string;
            profile_path?: string | null;
          }[];
          crew?: { id: number; name: string; job?: string }[];
        };
        videos?: { results?: Video[] };
        images?: { stills?: { file_path: string }[] };
      }
    >(`/tv/${seriesId}/season/${seasonNumber}/episode/${episodeNumber}`, {
      append_to_response: "credits,videos,images",
      include_image_language: "en,null",
    }),
  ]);

  const mapPeople = (
    people: { id: number; name: string; character?: string; profile_path?: string | null }[] = [],
  ): CastMember[] =>
    people.slice(0, 18).map((p) => ({
      id: p.id,
      name: p.name,
      character: p.character ?? "",
      profilePath: p.profile_path ?? null,
    }));

  const videos = (episode.videos?.results ?? []).filter((v) => v.site === "YouTube");
  const trailer =
    videos.find((v) => v.type === "Trailer" && v.official) ??
    videos.find((v) => v.type === "Trailer") ??
    videos.find((v) => v.type === "Teaser") ??
    videos[0] ??
    null;

  const episodeNumbers = (season.episodes ?? []).map((e) => e.episode_number).sort((a, b) => a - b);
  const index = episodeNumbers.indexOf(episodeNumber);

  return {
    ...toEpisode({ ...episode, season_number: episode.season_number ?? seasonNumber }),
    seriesId,
    seriesTitle: series.name ?? series.title ?? "Series",
    seriesBackdropPath: series.backdrop_path ?? null,
    seasonName: season.name || `Season ${seasonNumber}`,
    guestStars: mapPeople(episode.credits?.guest_stars),
    cast: mapPeople(episode.credits?.cast),
    crew: (episode.credits?.crew ?? [])
      .map((c) => ({ id: c.id, name: c.name, job: c.job ?? "" }))
      .filter((c) => ["Director", "Writer", "Story", "Screenplay", "Editor"].includes(c.job))
      .slice(0, 10),
    videos: videos.slice(0, 8),
    trailer,
    images: (episode.images?.stills ?? []).slice(0, 9).map((s) => s.file_path),
    previousEpisode: index > 0 ? episodeNumbers[index - 1] : null,
    nextEpisode: index >= 0 && index < episodeNumbers.length - 1 ? episodeNumbers[index + 1] : null,
    totalEpisodes: episodeNumbers.length,
  };
}
