import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { recommend, type AiRecommendation } from "./ai.server";
import type { DataResult } from "./data-result";

export const getAiRecommendations = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { prompt: string; seedTitles?: string[] }) =>
    z
      .object({
        prompt: z.string().trim().min(3).max(400),
        seedTitles: z.array(z.string().max(200)).max(10).default([]),
      })
      .parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<AiRecommendation[]>> =>
      recommend(data.prompt, data.seedTitles),
  );

