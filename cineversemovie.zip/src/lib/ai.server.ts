/** Server-only AI recommendation engine (Lovable AI Gateway + TMDB enrichment). */
import { fetchSearch } from "./tmdb.server";
import type { DataResult } from "./data-result";
import type { MovieSummary } from "./tmdb.types";

const GATEWAY_URL = "https://ai.gateway.lovable.dev/v1/chat/completions";
const MODEL = "google/gemini-3.5-flash";

export type AiRecommendation = {
  title: string;
  year: string | null;
  reason: string;
  movie: MovieSummary | null;
};

type Suggestion = { title: string; year?: string | number | null; reason?: string };

export async function recommend(
  prompt: string,
  seedTitles: string[],
): Promise<DataResult<AiRecommendation[]>> {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) {
    return { ok: false, reason: "not_configured", message: "AI service is not configured." };
  }

  const seedLine = seedTitles.length
    ? `The viewer already likes: ${seedTitles.slice(0, 10).join(", ")}.`
    : "";

  const response = await fetch(GATEWAY_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        {
          role: "system",
          content:
            "You are CineVerse AI, a film curator. Recommend real, existing feature films only. " +
            "Return between 5 and 8 recommendations. Keep each reason to one vivid sentence.",
        },
        { role: "user", content: `${seedLine}\nRequest: ${prompt}` },
      ],
      tools: [
        {
          type: "function",
          function: {
            name: "return_recommendations",
            description: "Return the curated film recommendations.",
            parameters: {
              type: "object",
              properties: {
                recommendations: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      title: { type: "string" },
                      year: { type: "string" },
                      reason: { type: "string" },
                    },
                    required: ["title", "reason"],
                    additionalProperties: false,
                  },
                },
              },
              required: ["recommendations"],
              additionalProperties: false,
            },
          },
        },
      ],
      tool_choice: { type: "function", function: { name: "return_recommendations" } },
    }),
  });

  if (!response.ok) {
    const body = await response.text();
    console.error(`[AI] gateway failed [${response.status}]: ${body}`);
    if (response.status === 429) {
      return { ok: false, reason: "error", message: "Too many requests — try again in a moment." };
    }
    if (response.status === 402) {
      return { ok: false, reason: "error", message: "AI credits are exhausted for this workspace." };
    }
    return { ok: false, reason: "error", message: "The recommendation engine is unavailable." };
  }

  const payload = (await response.json()) as {
    choices?: { message?: { tool_calls?: { function?: { arguments?: string } }[] } }[];
  };

  const raw = payload.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
  if (!raw) {
    return { ok: false, reason: "error", message: "No recommendations were returned." };
  }

  let suggestions: Suggestion[] = [];
  try {
    suggestions = (JSON.parse(raw).recommendations ?? []) as Suggestion[];
  } catch (error) {
    console.error("[AI] failed to parse tool arguments", error);
    return { ok: false, reason: "error", message: "The recommendation response was malformed." };
  }

  const enriched = await Promise.all(
    suggestions.slice(0, 8).map(async (item): Promise<AiRecommendation> => {
      let movie: MovieSummary | null = null;
      try {
        const found = await fetchSearch(item.title, 1);
        const year = item.year ? String(item.year).slice(0, 4) : null;
        movie =
          found.results.find((m) => (year ? m.releaseDate?.startsWith(year) : false)) ??
          found.results[0] ??
          null;
      } catch {
        movie = null;
      }
      return {
        title: item.title,
        year: item.year ? String(item.year).slice(0, 4) : null,
        reason: item.reason ?? "",
        movie,
      };
    }),
  );

  return { ok: true, data: enriched };
}
