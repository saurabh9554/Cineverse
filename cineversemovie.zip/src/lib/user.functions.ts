import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { publicSupabase } from "./supabase-public.server";

/* --------------------------------- profile --------------------------------- */

export const getMyAccount = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const [{ data: profile }, { data: roles }, { count: watchCount }, { count: reviewCount }] =
      await Promise.all([
        supabase.from("profiles").select("*").eq("id", userId).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", userId),
        supabase.from("watchlist").select("*", { count: "exact", head: true }).eq("user_id", userId),
        supabase.from("reviews").select("*", { count: "exact", head: true }).eq("user_id", userId),
      ]);

    return {
      profile,
      roles: (roles ?? []).map((r) => r.role as string),
      isAdmin: (roles ?? []).some((r) => r.role === "admin"),
      stats: { watchlist: watchCount ?? 0, reviews: reviewCount ?? 0 },
    };
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { displayName: string; username: string; bio: string; avatarUrl: string }) =>
    z
      .object({
        displayName: z.string().trim().min(1).max(60),
        username: z
          .string()
          .trim()
          .min(3)
          .max(30)
          .regex(/^[a-z0-9_]+$/, "Use lowercase letters, numbers and underscores only"),
        bio: z.string().trim().max(400).default(""),
        avatarUrl: z.string().trim().max(500).default(""),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("profiles")
      .update({
        display_name: data.displayName,
        username: data.username,
        bio: data.bio,
        avatar_url: data.avatarUrl || null,
      })
      .eq("id", context.userId);

    if (error) throw new Error(error.message);
    return { ok: true };
  });

/* -------------------------------- watchlist -------------------------------- */

export const getMyWatchlist = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("watchlist")
      .select("*")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const toggleWatchlist = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: {
      movieId: number;
      title: string;
      posterPath?: string | null;
      releaseDate?: string | null;
      voteAverage?: number | null;
    }) =>
      z
        .object({
          movieId: z.number().int().positive(),
          title: z.string().min(1).max(300),
          posterPath: z.string().max(300).nullable().optional(),
          releaseDate: z.string().max(20).nullable().optional(),
          voteAverage: z.number().min(0).max(10).nullable().optional(),
        })
        .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: existing } = await supabase
      .from("watchlist")
      .select("id")
      .eq("user_id", userId)
      .eq("movie_id", data.movieId)
      .maybeSingle();

    if (existing) {
      const { error } = await supabase.from("watchlist").delete().eq("id", existing.id);
      if (error) throw new Error(error.message);
      return { inWatchlist: false };
    }

    const { error } = await supabase.from("watchlist").insert({
      user_id: userId,
      movie_id: data.movieId,
      title: data.title,
      poster_path: data.posterPath ?? null,
      release_date: data.releaseDate ?? null,
      vote_average: data.voteAverage ?? null,
    });
    if (error) throw new Error(error.message);
    return { inWatchlist: true };
  });

export const setWatchStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; status: "want" | "watching" | "watched" }) =>
    z.object({ id: z.string().uuid(), status: z.enum(["want", "watching", "watched"]) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("watchlist")
      .update({ status: data.status })
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const removeFromWatchlist = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("watchlist")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getWatchlistIds = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase
      .from("watchlist")
      .select("movie_id")
      .eq("user_id", context.userId);
    return (data ?? []).map((r) => r.movie_id);
  });

/* --------------------------------- reviews --------------------------------- */

export const getMovieReviews = createServerFn({ method: "GET" })
  .inputValidator((input: { movieId: number }) =>
    z.object({ movieId: z.number().int().positive() }).parse(input),
  )
  .handler(async ({ data }) => {
    const supabase = publicSupabase();
    const { data: reviews, error } = await supabase
      .from("reviews")
      .select("id, user_id, rating, content, created_at")
      .eq("movie_id", data.movieId)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) {
      console.error("[reviews] read failed", error.message);
      return [];
    }

    const ids = [...new Set((reviews ?? []).map((r) => r.user_id))];
    const { data: profiles } = ids.length
      ? await supabase.from("profiles").select("id, display_name, username, avatar_url").in("id", ids)
      : { data: [] };

    const byId = new Map((profiles ?? []).map((p) => [p.id, p]));
    return (reviews ?? []).map((r) => ({
      id: r.id,
      rating: r.rating,
      content: r.content,
      createdAt: r.created_at,
      userId: r.user_id,
      author: byId.get(r.user_id)?.display_name ?? byId.get(r.user_id)?.username ?? "Cinephile",
      avatarUrl: byId.get(r.user_id)?.avatar_url ?? null,
    }));
  });

export const upsertReview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { movieId: number; movieTitle: string; rating: number; content: string }) =>
    z
      .object({
        movieId: z.number().int().positive(),
        movieTitle: z.string().min(1).max(300),
        rating: z.number().int().min(1).max(10),
        content: z.string().trim().max(4000).default(""),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("reviews").upsert(
      {
        user_id: context.userId,
        movie_id: data.movieId,
        movie_title: data.movieTitle,
        rating: data.rating,
        content: data.content,
      },
      { onConflict: "user_id,movie_id" },
    );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteMyReview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("reviews")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const getMyReviews = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("reviews")
      .select("*")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });
