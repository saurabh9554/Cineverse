/** Client-safe catalogue of the film industries CineVerse covers. */

export type Industry = {
  slug: string;
  name: string;
  /** ISO 639-1 original-language code used for TMDB discover. */
  language: string;
  /** Optional ISO 3166-1 region used for release-date windows. */
  region?: string;
  tagline: string;
  accent: string;
};

export const INDUSTRIES: Industry[] = [
  {
    slug: "hollywood",
    name: "Hollywood",
    language: "en",
    region: "US",
    tagline: "Blockbusters, prestige drama and everything in between.",
    accent: "from-primary/30",
  },
  {
    slug: "bollywood",
    name: "Bollywood",
    language: "hi",
    region: "IN",
    tagline: "Hindi cinema — song, spectacle and the biggest stars in the world.",
    accent: "from-gold/30",
  },
  {
    slug: "tamil",
    name: "Tamil",
    language: "ta",
    region: "IN",
    tagline: "Kollywood's mass heroes, sharp thrillers and rural epics.",
    accent: "from-primary/30",
  },
  {
    slug: "telugu",
    name: "Telugu",
    language: "te",
    region: "IN",
    tagline: "Tollywood spectacle at maximum volume.",
    accent: "from-gold/30",
  },
  {
    slug: "kannada",
    name: "Kannada",
    language: "kn",
    region: "IN",
    tagline: "Sandalwood — from cult classics to pan-India breakouts.",
    accent: "from-primary/30",
  },
  {
    slug: "malayalam",
    name: "Malayalam",
    language: "ml",
    region: "IN",
    tagline: "Mollywood realism, celebrated worldwide for its writing.",
    accent: "from-primary/30",
  },
  {
    slug: "punjabi",
    name: "Punjabi",
    language: "pa",
    region: "IN",
    tagline: "Pollywood comedy, romance and family sagas.",
    accent: "from-gold/30",
  },
  {
    slug: "marathi",
    name: "Marathi",
    language: "mr",
    region: "IN",
    tagline: "Intimate, award-winning storytelling from Maharashtra.",
    accent: "from-primary/30",
  },
  {
    slug: "bengali",
    name: "Bengali",
    language: "bn",
    region: "IN",
    tagline: "Tollygunge auteurs and the legacy of Indian art cinema.",
    accent: "from-primary/30",
  },
  {
    slug: "gujarati",
    name: "Gujarati",
    language: "gu",
    region: "IN",
    tagline: "Dhollywood's modern urban comedies and dramas.",
    accent: "from-gold/30",
  },
  {
    slug: "bhojpuri",
    name: "Bhojpuri",
    language: "bho",
    region: "IN",
    tagline: "High-energy popular cinema from the Bhojpuri belt.",
    accent: "from-gold/30",
  },
  {
    slug: "korean",
    name: "Korean",
    language: "ko",
    region: "KR",
    tagline: "Hallyu thrillers, romance and genre-bending originals.",
    accent: "from-primary/30",
  },
  {
    slug: "japanese",
    name: "Japanese",
    language: "ja",
    region: "JP",
    tagline: "Anime features, samurai epics and quiet masterpieces.",
    accent: "from-primary/30",
  },
  {
    slug: "spanish",
    name: "Spanish",
    language: "es",
    region: "ES",
    tagline: "Iberian and Latin American cinema in full colour.",
    accent: "from-gold/30",
  },
  {
    slug: "french",
    name: "French",
    language: "fr",
    region: "FR",
    tagline: "New Wave heritage and contemporary European craft.",
    accent: "from-primary/30",
  },
];

export const INDIAN_INDUSTRIES = INDUSTRIES.filter((i) => i.region === "IN");

export function findIndustry(slug: string) {
  return INDUSTRIES.find((i) => i.slug === slug) ?? null;
}
