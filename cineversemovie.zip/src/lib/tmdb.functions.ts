import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import {
  fetchCollection,
  fetchDiscover,
  fetchGenres,
  fetchHome,
  fetchList,
  fetchIndustry,
  fetchMovie,
  fetchPerson,
  fetchSearch,
  fetchEpisode,
  fetchSeason,
  fetchSeriesHub,
  fetchTv,
  fetchTvDiscover,
  fetchTvList,
  fetchTvSearch,
  fetchTrending,
  safe,
  type HomePayload,
  type IndustryPayload,
  type SeriesHubPayload,
  type TvCategory,
  type ListCategory,
} from "./tmdb.server";
import type { DataResult } from "./data-result";
import type {
  CollectionDetail,
  Genre,
  MovieDetail,
  PagedMovies,
  PersonDetail,
  EpisodeDetail,
  SeasonDetail,
  TvDetail,
} from "./tmdb.types";

const pageSchema = z.object({ page: z.number().int().min(1).max(500).default(1) });

const discoverSchema = z.object({
  page: z.number().int().min(1).max(500).default(1),
  genres: z.array(z.number().int()).max(10).optional(),
  yearFrom: z.number().int().min(1888).max(2100).optional(),
  yearTo: z.number().int().min(1888).max(2100).optional(),
  minRating: z.number().min(0).max(10).optional(),
  minVotes: z.number().int().min(0).max(100000).optional(),
  sortBy: z.string().max(40).optional(),
  language: z.string().max(5).optional(),
});

export const getHome = createServerFn({ method: "GET" }).handler(
  async (): Promise<DataResult<HomePayload>> => safe(() => fetchHome()),
);

export const getGenres = createServerFn({ method: "GET" }).handler(
  async (): Promise<DataResult<Genre[]>> => safe(() => fetchGenres()),
);

export const getTrending = createServerFn({ method: "GET" })
  .inputValidator((input: { page?: number; window?: "day" | "week" }) =>
    z
      .object({
        page: z.number().int().min(1).max(500).default(1),
        window: z.enum(["day", "week"]).default("week"),
      })
      .parse(input ?? {}),
  )
  .handler(
    async ({ data }): Promise<DataResult<PagedMovies>> =>
      safe(() => fetchTrending(data.window, data.page)),
  );

export const getCategory = createServerFn({ method: "GET" })
  .inputValidator((input: { category: ListCategory; page?: number }) =>
    z
      .object({
        category: z.enum(["popular", "top_rated", "upcoming", "now_playing"]),
        page: z.number().int().min(1).max(500).default(1),
      })
      .parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<PagedMovies>> =>
      safe(() => fetchList(data.category, data.page)),
  );

export const discoverMovies = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => discoverSchema.parse(input ?? {}))
  .handler(
    async ({ data }): Promise<DataResult<PagedMovies>> => safe(() => fetchDiscover(data)),
  );

export const searchMovies = createServerFn({ method: "GET" })
  .inputValidator((input: { query: string; page?: number }) =>
    z
      .object({ query: z.string().max(120).default(""), page: z.number().int().min(1).max(500).default(1) })
      .parse(input ?? {}),
  )
  .handler(
    async ({ data }): Promise<DataResult<PagedMovies>> =>
      safe(() => fetchSearch(data.query, data.page)),
  );

export const getMovieDetail = createServerFn({ method: "GET" })
  .inputValidator((input: { id: number }) =>
    z.object({ id: z.number().int().positive() }).parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<MovieDetail>> => safe(() => fetchMovie(data.id)),
  );

export const getPageMeta = createServerFn({ method: "GET" }).handler(async () =>
  pageSchema.pick({}).parse({}),
);

export const getPerson = createServerFn({ method: "GET" })
  .inputValidator((input: { id: number }) =>
    z.object({ id: z.number().int().positive() }).parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<PersonDetail>> => safe(() => fetchPerson(data.id)),
  );

export const getCollection = createServerFn({ method: "GET" })
  .inputValidator((input: { id: number }) =>
    z.object({ id: z.number().int().positive() }).parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<CollectionDetail>> =>
      safe(() => fetchCollection(data.id)),
  );

export const getIndustry = createServerFn({ method: "GET" })
  .inputValidator((input: { language: string }) =>
    z.object({ language: z.string().min(2).max(5) }).parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<IndustryPayload>> =>
      safe(() => fetchIndustry(data.language)),
  );

/* -------------------------------- web series -------------------------------- */

export const getSeriesHub = createServerFn({ method: "GET" }).handler(
  async (): Promise<DataResult<SeriesHubPayload>> => safe(() => fetchSeriesHub()),
);

export const getTvCategory = createServerFn({ method: "GET" })
  .inputValidator((input: { category: TvCategory; page?: number }) =>
    z
      .object({
        category: z.enum(["popular", "top_rated", "on_the_air", "airing_today"]),
        page: z.number().int().min(1).max(500).default(1),
      })
      .parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<PagedMovies>> =>
      safe(() => fetchTvList(data.category, data.page)),
  );

export const searchSeries = createServerFn({ method: "GET" })
  .inputValidator((input: { query: string; page?: number }) =>
    z
      .object({
        query: z.string().max(120).default(""),
        page: z.number().int().min(1).max(500).default(1),
      })
      .parse(input ?? {}),
  )
  .handler(
    async ({ data }): Promise<DataResult<PagedMovies>> =>
      safe(() => fetchTvSearch(data.query, data.page)),
  );

export const discoverSeries = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => discoverSchema.parse(input ?? {}))
  .handler(async ({ data }): Promise<DataResult<PagedMovies>> => safe(() => fetchTvDiscover(data)));

export const getSeriesDetail = createServerFn({ method: "GET" })
  .inputValidator((input: { id: number }) =>
    z.object({ id: z.number().int().positive() }).parse(input),
  )
  .handler(async ({ data }): Promise<DataResult<TvDetail>> => safe(() => fetchTv(data.id)));

export const getSeason = createServerFn({ method: "GET" })
  .inputValidator((input: { seriesId: number; seasonNumber: number }) =>
    z
      .object({
        seriesId: z.number().int().positive(),
        seasonNumber: z.number().int().min(0).max(200),
      })
      .parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<SeasonDetail>> =>
      safe(() => fetchSeason(data.seriesId, data.seasonNumber)),
  );

export const getEpisode = createServerFn({ method: "GET" })
  .inputValidator((input: { seriesId: number; seasonNumber: number; episodeNumber: number }) =>
    z
      .object({
        seriesId: z.number().int().positive(),
        seasonNumber: z.number().int().min(0).max(200),
        episodeNumber: z.number().int().min(0).max(2000),
      })
      .parse(input),
  )
  .handler(
    async ({ data }): Promise<DataResult<EpisodeDetail>> =>
      safe(() => fetchEpisode(data.seriesId, data.seasonNumber, data.episodeNumber)),
  );
