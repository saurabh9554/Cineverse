import { createFileRoute, Link } from "@tanstack/react-router";

import { PageHeader } from "@/components/common/PageHeader";
import { listNews, type NewsArticle } from "@/lib/news.functions";

export const Route = createFileRoute("/news/")({
  loader: () => listNews(),
  head: () => ({
    meta: [
      { title: "Film News & Editorials — CineVerse AI" },
      {
        name: "description",
        content:
          "Industry news, festival coverage and editorial deep dives from the CineVerse AI newsroom.",
      },
      { property: "og:title", content: "Film News & Editorials — CineVerse AI" },
      {
        property: "og:description",
        content: "Industry news, festival coverage and editorial deep dives on film.",
      },
    ],
  }),
  component: NewsPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">No stories yet.</p>
  ),
});

function NewsPage() {
  const articles: NewsArticle[] = Route.useLoaderData();

  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Newsroom"
        title="Film news"
        description="Release announcements, box-office analysis and long-form editorials."
      />

      {articles.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-16 text-center text-sm text-muted-foreground">
          No stories have been published yet. Editors can publish articles from the admin dashboard.
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {articles.map((article) => (
            <Link
              key={article.id}
              to="/news/$slug"
              params={{ slug: article.slug }}
              className="group overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-primary/50"
            >
              {article.coverImageUrl ? (
                <img
                  src={article.coverImageUrl}
                  alt=""
                  loading="lazy"
                  className="h-48 w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <div className="h-2 w-full bg-gradient-primary" />
              )}
              <div className="p-6">
                <span className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">
                  {article.category}
                </span>
                <h2 className="mt-2 text-xl font-semibold leading-snug">{article.title}</h2>
                <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">{article.excerpt}</p>
                {article.publishedAt ? (
                  <time
                    dateTime={article.publishedAt}
                    className="mt-4 block text-xs text-muted-foreground"
                  >
                    {new Date(article.publishedAt).toLocaleDateString(undefined, {
                      dateStyle: "medium",
                    })}
                  </time>
                ) : null}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
