import { createFileRoute, Link } from "@tanstack/react-router";

import { PageHeader } from "@/components/common/PageHeader";
import { SetupNotice } from "@/components/common/SetupNotice";
import { getGenres } from "@/lib/tmdb.functions";
import type { Genre } from "@/lib/tmdb.types";
import type { DataResult } from "@/lib/data-result";

export const Route = createFileRoute("/genres")({
  loader: () => getGenres(),
  head: () => ({
    meta: [
      { title: "Browse Movies by Genre — CineVerse AI" },
      {
        name: "description",
        content:
          "Jump into action, horror, sci-fi, romance, animation and every other genre with curated, filterable film lists.",
      },
      { property: "og:title", content: "Browse Movies by Genre — CineVerse AI" },
      {
        property: "og:description",
        content: "Action, horror, sci-fi, romance and more — browse films by genre.",
      },
    ],
  }),
  component: GenresPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">No genres available.</p>
  ),
});

const ACCENTS = [
  "from-primary/30 to-primary/5",
  "from-accent/30 to-accent/5",
  "from-sky-500/25 to-sky-500/5",
  "from-emerald-500/25 to-emerald-500/5",
  "from-fuchsia-500/25 to-fuchsia-500/5",
  "from-amber-500/25 to-amber-500/5",
];

function GenresPage() {
  const result: DataResult<Genre[]> = Route.useLoaderData();

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Browse"
        title="Genres"
        description="Pick a mood and dive into a filtered, sortable list of the best films in it."
      />

      {result.ok ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {result.data.map((genre, index) => (
            <Link
              key={genre.id}
              to="/search"
              search={{
                q: "",
                page: 1,
                genres: [genre.id],
                yearFrom: 1950,
                yearTo: new Date().getFullYear() + 2,
                minRating: 0,
                sortBy: "popularity.desc",
              }}
              className={`group relative overflow-hidden rounded-2xl border border-border bg-gradient-to-br ${
                ACCENTS[index % ACCENTS.length]
              } p-6 transition-transform hover:-translate-y-1`}
            >
              <span className="font-display text-2xl uppercase tracking-wide">{genre.name}</span>
              <span className="mt-1 block text-xs text-muted-foreground">
                Explore {genre.name.toLowerCase()} films
              </span>
            </Link>
          ))}
        </div>
      ) : (
        <SetupNotice result={result} />
      )}
    </div>
  );
}
