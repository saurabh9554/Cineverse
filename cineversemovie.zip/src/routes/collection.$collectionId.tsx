import { createFileRoute, notFound } from "@tanstack/react-router";

import { MovieGrid } from "@/components/movie/MovieGrid";
import { PageHeader } from "@/components/common/PageHeader";
import { getCollection } from "@/lib/tmdb.functions";
import { backdropUrl } from "@/lib/tmdb.types";
import type { CollectionDetail } from "@/lib/tmdb.types";

export const Route = createFileRoute("/collection/$collectionId")({
  loader: async ({ params }) => {
    const id = Number(params.collectionId);
    if (!Number.isInteger(id) || id <= 0) throw notFound();
    const result = await getCollection({ data: { id } });
    if (!result.ok) throw new Error(result.message);
    return result.data;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Franchise unavailable — CineVerse AI" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.name} — Franchise Guide | CineVerse AI`;
    const description =
      loaderData.overview.slice(0, 155) ||
      `Every film in the ${loaderData.name} franchise, in release order, with ratings and trailers.`;
    const image = backdropUrl(loaderData.backdropPath, "w1280");
    const meta = [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ];
    if (image) {
      meta.push({ property: "og:image", content: image }, { name: "twitter:image", content: image });
    }
    return { meta };
  },
  component: CollectionPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">
      That franchise doesn't exist.
    </p>
  ),
});

function CollectionPage() {
  const collection: CollectionDetail = Route.useLoaderData();
  const backdrop = backdropUrl(collection.backdropPath, "w1280");

  return (
    <div className="pb-24">
      <div className="relative">
        {backdrop ? (
          <img src={backdrop} alt="" className="absolute inset-0 h-full w-full object-cover" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-background/60" />
        <div className="relative mx-auto max-w-7xl px-4 pt-28 sm:px-6 lg:px-8">
          <PageHeader
            eyebrow="Franchise"
            title={collection.name}
            description={collection.overview || `${collection.parts.length} films in release order.`}
          />
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <MovieGrid movies={collection.parts} />
      </div>
    </div>
  );
}
