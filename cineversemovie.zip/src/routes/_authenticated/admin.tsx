import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { deleteArticle, getAdminOverview, saveArticle } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — CineVerse AI" },
      { name: "description", content: "Platform analytics and editorial controls for CineVerse AI." },
      { property: "og:title", content: "Admin Dashboard — CineVerse AI" },
      { property: "og:description", content: "Platform analytics and editorial controls." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

const EMPTY_ARTICLE = {
  title: "",
  slug: "",
  excerpt: "",
  content: "",
  category: "Industry",
  coverImageUrl: "",
  published: true,
};

function AdminPage() {
  const queryClient = useQueryClient();
  const overviewFn = useServerFn(getAdminOverview);
  const saveFn = useServerFn(saveArticle);
  const deleteFn = useServerFn(deleteArticle);
  const [draft, setDraft] = useState(EMPTY_ARTICLE);

  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-overview"],
    queryFn: () => overviewFn(),
    retry: false,
  });

  const publish = useMutation({
    mutationFn: () => saveFn({ data: draft }),
    onSuccess: () => {
      toast.success("Article saved");
      setDraft(EMPTY_ARTICLE);
      queryClient.invalidateQueries({ queryKey: ["admin-overview"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Article deleted");
      queryClient.invalidateQueries({ queryKey: ["admin-overview"] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  if (isLoading) {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-40 text-center">
        <h1 className="font-display text-3xl uppercase">Admins only</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          This dashboard is restricted to accounts with the admin role.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Operations"
        title="Admin dashboard"
        description="Audience analytics, community activity and the editorial newsroom."
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Metric label="Members" value={data.totals.users} />
        <Metric label="Saved films" value={data.totals.watchlistItems} />
        <Metric label="Reviews" value={data.totals.reviews} />
        <Metric label="Articles" value={data.totals.articles} />
        <Metric label="Events (14d)" value={data.totals.events} />
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Panel title="Activity — last 14 days">
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={data.activity}>
              <defs>
                <linearGradient id="activityFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.55} />
                  <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="date" stroke="var(--color-muted-foreground)" fontSize={11} />
              <YAxis stroke="var(--color-muted-foreground)" fontSize={11} allowDecimals={false} />
              <Tooltip
                contentStyle={{
                  background: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  borderRadius: 12,
                }}
              />
              <Area
                type="monotone"
                dataKey="count"
                stroke="var(--color-primary)"
                fill="url(#activityFill)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </Panel>

        <Panel title="Most saved films">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={data.topSaved} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" horizontal={false} />
              <XAxis type="number" stroke="var(--color-muted-foreground)" fontSize={11} allowDecimals={false} />
              <YAxis
                type="category"
                dataKey="title"
                width={130}
                stroke="var(--color-muted-foreground)"
                fontSize={11}
              />
              <Tooltip
                cursor={{ fill: "var(--color-surface)" }}
                contentStyle={{
                  background: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  borderRadius: 12,
                }}
              />
              <Bar dataKey="count" fill="var(--color-accent)" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Panel title="Newest members">
          <ul className="divide-y divide-border text-sm">
            {data.recentUsers.map((user) => (
              <li key={user.id} className="flex items-center justify-between gap-4 py-3">
                <span className="truncate">{user.display_name ?? user.username ?? "Member"}</span>
                <time className="shrink-0 text-xs text-muted-foreground">
                  {new Date(user.created_at).toLocaleDateString()}
                </time>
              </li>
            ))}
            {data.recentUsers.length === 0 ? (
              <li className="py-3 text-muted-foreground">No members yet.</li>
            ) : null}
          </ul>
        </Panel>

        <Panel title="Latest reviews">
          <ul className="divide-y divide-border text-sm">
            {data.recentReviews.map((review) => (
              <li key={review.id} className="py-3">
                <div className="flex items-center justify-between gap-4">
                  <span className="truncate font-medium">{review.movie_title}</span>
                  <span className="shrink-0 text-gold">{review.rating}/10</span>
                </div>
                {review.content ? (
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{review.content}</p>
                ) : null}
              </li>
            ))}
            {data.recentReviews.length === 0 ? (
              <li className="py-3 text-muted-foreground">No reviews yet.</li>
            ) : null}
          </ul>
        </Panel>
      </div>

      <section className="mt-12 grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
        <form
          className="space-y-4 rounded-2xl border border-border bg-card p-6"
          onSubmit={(event) => {
            event.preventDefault();
            publish.mutate();
          }}
        >
          <h2 className="font-display text-2xl uppercase">Publish a story</h2>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                required
                value={draft.title}
                onChange={(event) => {
                  const title = event.target.value;
                  setDraft((prev) => ({
                    ...prev,
                    title,
                    slug: title
                      .toLowerCase()
                      .replace(/[^a-z0-9]+/g, "-")
                      .replace(/^-|-$/g, "")
                      .slice(0, 90),
                  }));
                }}
                className="bg-surface"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">Slug</Label>
              <Input
                id="slug"
                required
                value={draft.slug}
                onChange={(event) => setDraft((prev) => ({ ...prev, slug: event.target.value }))}
                className="bg-surface"
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={draft.category}
                onChange={(event) => setDraft((prev) => ({ ...prev, category: event.target.value }))}
                className="bg-surface"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cover">Cover image URL</Label>
              <Input
                id="cover"
                value={draft.coverImageUrl}
                onChange={(event) =>
                  setDraft((prev) => ({ ...prev, coverImageUrl: event.target.value }))
                }
                placeholder="https://…"
                className="bg-surface"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="excerpt">Excerpt</Label>
            <Textarea
              id="excerpt"
              rows={2}
              maxLength={400}
              value={draft.excerpt}
              onChange={(event) => setDraft((prev) => ({ ...prev, excerpt: event.target.value }))}
              className="resize-none bg-surface"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Body</Label>
            <Textarea
              id="content"
              rows={8}
              value={draft.content}
              onChange={(event) => setDraft((prev) => ({ ...prev, content: event.target.value }))}
              placeholder="Separate paragraphs with a blank line."
              className="bg-surface"
            />
          </div>

          <div className="flex items-center gap-3">
            <Switch
              id="published"
              checked={draft.published}
              onCheckedChange={(published) => setDraft((prev) => ({ ...prev, published }))}
            />
            <Label htmlFor="published">Publish immediately</Label>
          </div>

          <Button type="submit" variant="hero" disabled={publish.isPending}>
            {publish.isPending ? (
              <Loader2 className="animate-spin" aria-hidden />
            ) : (
              <Plus aria-hidden />
            )}
            Save article
          </Button>
        </form>

        <Panel title="Newsroom">
          <ul className="divide-y divide-border text-sm">
            {data.articles.map((article) => (
              <li key={article.id} className="flex items-center gap-3 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{article.title}</p>
                  <div className="mt-1 flex items-center gap-2">
                    <Badge variant={article.published ? "default" : "secondary"}>
                      {article.published ? "Live" : "Draft"}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{article.category}</span>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label={`Delete ${article.title}`}
                  onClick={() => remove.mutate(article.id)}
                >
                  <Trash2 className="text-muted-foreground" aria-hidden />
                </Button>
              </li>
            ))}
            {data.articles.length === 0 ? (
              <li className="py-3 text-muted-foreground">No articles yet.</li>
            ) : null}
          </ul>
        </Panel>
      </section>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <p className="font-display text-3xl">{value.toLocaleString()}</p>
      <p className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <h2 className="mb-4 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
        {title}
      </h2>
      {children}
    </div>
  );
}
