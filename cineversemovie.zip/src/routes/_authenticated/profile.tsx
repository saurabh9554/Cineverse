import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { Loader2, Shield, Star } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getMyAccount, getMyReviews, updateMyProfile } from "@/lib/user.functions";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Your Profile — CineVerse AI" },
      { name: "description", content: "Manage your CineVerse AI profile, stats and reviews." },
      { property: "og:title", content: "Your Profile — CineVerse AI" },
      { property: "og:description", content: "Manage your CineVerse AI profile, stats and reviews." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const queryClient = useQueryClient();
  const accountFn = useServerFn(getMyAccount);
  const reviewsFn = useServerFn(getMyReviews);
  const updateFn = useServerFn(updateMyProfile);

  const { data: account, isLoading } = useQuery({
    queryKey: ["account"],
    queryFn: () => accountFn(),
  });
  const { data: reviews = [] } = useQuery({ queryKey: ["my-reviews"], queryFn: () => reviewsFn() });

  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");

  useEffect(() => {
    if (!account?.profile) return;
    setDisplayName(account.profile.display_name ?? "");
    setUsername(account.profile.username ?? "");
    setBio(account.profile.bio ?? "");
    setAvatarUrl(account.profile.avatar_url ?? "");
  }, [account?.profile]);

  const save = useMutation({
    mutationFn: () => updateFn({ data: { displayName, username, bio, avatarUrl } }),
    onSuccess: () => {
      toast.success("Profile updated");
      queryClient.invalidateQueries({ queryKey: ["account"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  if (isLoading) {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Account"
        title="Your profile"
        description="Your public identity across reviews and the CineVerse community."
        actions={
          account?.isAdmin ? (
            <Button variant="glass" asChild>
              <Link to="/admin">
                <Shield aria-hidden /> Admin dashboard
              </Link>
            </Button>
          ) : undefined
        }
      />

      <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_240px]">
        <form
          className="space-y-5 rounded-2xl border border-border bg-card p-6"
          onSubmit={(event) => {
            event.preventDefault();
            save.mutate();
          }}
        >
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={avatarUrl || undefined} alt="" />
              <AvatarFallback>{(displayName || "C").slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1 space-y-2">
              <Label htmlFor="avatar">Avatar URL</Label>
              <Input
                id="avatar"
                value={avatarUrl}
                onChange={(event) => setAvatarUrl(event.target.value)}
                placeholder="https://…"
                className="bg-surface"
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="display-name">Display name</Label>
              <Input
                id="display-name"
                value={displayName}
                onChange={(event) => setDisplayName(event.target.value)}
                required
                className="bg-surface"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={username}
                onChange={(event) => setUsername(event.target.value.toLowerCase())}
                required
                className="bg-surface"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              value={bio}
              rows={4}
              maxLength={400}
              onChange={(event) => setBio(event.target.value)}
              placeholder="Favourite director, comfort film, letterboxd energy…"
              className="resize-none bg-surface"
            />
          </div>

          <Button type="submit" variant="hero" disabled={save.isPending}>
            {save.isPending ? <Loader2 className="animate-spin" aria-hidden /> : null} Save changes
          </Button>
        </form>

        <aside className="space-y-4">
          <div className="rounded-2xl border border-border bg-card p-6 text-center">
            <p className="font-display text-4xl">{account?.stats.watchlist ?? 0}</p>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Saved films</p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-6 text-center">
            <p className="font-display text-4xl">{account?.stats.reviews ?? 0}</p>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Reviews written</p>
          </div>
        </aside>
      </div>

      <section className="mt-12">
        <h2 className="mb-4 font-display text-2xl uppercase tracking-wide">Your reviews</h2>
        {reviews.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
            You haven't reviewed anything yet.
          </p>
        ) : (
          <ul className="space-y-3">
            {reviews.map((review) => (
              <li key={review.id} className="rounded-2xl border border-border bg-card p-5">
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
                  <Link
                    to="/movie/$movieId"
                    params={{ movieId: String(review.movie_id) }}
                    className="truncate font-semibold hover:text-primary"
                  >
                    {review.movie_title}
                  </Link>
                  <span className="inline-flex shrink-0 items-center gap-1 text-sm text-gold">
                    <Star className="h-4 w-4 fill-current" aria-hidden />
                    {review.rating}/10
                  </span>
                </div>
                {review.content ? (
                  <p className="mt-2 text-sm text-muted-foreground">{review.content}</p>
                ) : null}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
