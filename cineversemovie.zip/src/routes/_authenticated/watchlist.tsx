import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/common/PageHeader";
import { Button } from "@/components/ui/button";
import { getMyWatchlist, removeFromWatchlist, setWatchStatus } from "@/lib/user.functions";
import { posterUrl, releaseYear } from "@/lib/tmdb.types";
import { cn } from "@/lib/utils";

const STATUSES = [
  { value: "want", label: "Want to watch" },
  { value: "watching", label: "Watching" },
  { value: "watched", label: "Watched" },
] as const;

export const Route = createFileRoute("/_authenticated/watchlist")({
  head: () => ({
    meta: [
      { title: "Your Watchlist — CineVerse AI" },
      { name: "description", content: "Every film you've saved, with viewing status tracking." },
      { property: "og:title", content: "Your Watchlist — CineVerse AI" },
      { property: "og:description", content: "Every film you've saved, with status tracking." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: WatchlistPage,
});

function WatchlistPage() {
  const queryClient = useQueryClient();
  const listFn = useServerFn(getMyWatchlist);
  const statusFn = useServerFn(setWatchStatus);
  const removeFn = useServerFn(removeFromWatchlist);

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["watchlist"],
    queryFn: () => listFn(),
  });

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["watchlist"] });
    queryClient.invalidateQueries({ queryKey: ["watchlist-ids"] });
  };

  const update = useMutation({
    mutationFn: (input: { id: string; status: "want" | "watching" | "watched" }) =>
      statusFn({ data: input }),
    onSuccess: refresh,
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: (id: string) => removeFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Removed from watchlist");
      refresh();
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <div className="mx-auto max-w-5xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Your library"
        title="Watchlist"
        description="Track what you want to watch, what you're mid-way through and what you've finished."
      />

      {isLoading ? (
        <div className="grid min-h-[30vh] place-items-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden />
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-16 text-center">
          <p className="text-sm text-muted-foreground">Your watchlist is empty.</p>
          <Button variant="hero" className="mt-5" asChild>
            <Link to="/trending">Browse trending films</Link>
          </Button>
        </div>
      ) : (
        <ul className="space-y-4">
          {items.map((item) => (
            <li
              key={item.id}
              className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-4 sm:flex-row sm:items-center"
            >
              <Link
                to="/movie/$movieId"
                params={{ movieId: String(item.movie_id) }}
                className="shrink-0"
              >
                {posterUrl(item.poster_path) ? (
                  <img
                    src={posterUrl(item.poster_path)!}
                    alt={item.title}
                    loading="lazy"
                    width={185}
                    height={278}
                    className="h-28 w-20 rounded-lg object-cover"
                  />
                ) : (
                  <div className="h-28 w-20 rounded-lg bg-surface" />
                )}
              </Link>

              <div className="min-w-0 flex-1">
                <Link
                  to="/movie/$movieId"
                  params={{ movieId: String(item.movie_id) }}
                  className="truncate text-lg font-semibold hover:text-primary"
                >
                  {item.title}
                </Link>
                <p className="text-sm text-muted-foreground">{releaseYear(item.release_date)}</p>

                <div className="mt-3 flex flex-wrap gap-2">
                  {STATUSES.map((status) => (
                    <button
                      key={status.value}
                      type="button"
                      aria-pressed={item.status === status.value}
                      onClick={() => update.mutate({ id: item.id, status: status.value })}
                      className={cn(
                        "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                        item.status === status.value
                          ? "border-primary bg-primary/15 text-primary"
                          : "border-border text-muted-foreground hover:text-foreground",
                      )}
                    >
                      {status.label}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                variant="ghost"
                size="icon"
                aria-label={`Remove ${item.title} from watchlist`}
                onClick={() => remove.mutate(item.id)}
              >
                <Trash2 className="text-muted-foreground" aria-hidden />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
