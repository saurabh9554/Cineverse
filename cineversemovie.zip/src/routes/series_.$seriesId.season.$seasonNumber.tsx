import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CalendarDays, ChevronLeft, Star } from "lucide-react";

import { getSeason } from "@/lib/tmdb.functions";
import { backdropUrl, posterUrl, releaseYear, stillUrl } from "@/lib/tmdb.types";
import type { SeasonDetail } from "@/lib/tmdb.types";

export const Route = createFileRoute("/series_/$seriesId/season/$seasonNumber")({
  loader: async ({ params }) => {
    const seriesId = Number(params.seriesId);
    const seasonNumber = Number(params.seasonNumber);
    if (!Number.isInteger(seriesId) || seriesId <= 0 || !Number.isInteger(seasonNumber)) {
      throw notFound();
    }
    const result = await getSeason({ data: { seriesId, seasonNumber } });
    if (!result.ok) throw new Error(result.message);
    return result.data;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Season unavailable — CineVerse AI" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.seriesTitle} — ${loaderData.name} Episodes | CineVerse AI`;
    const description =
      loaderData.overview?.slice(0, 155) ||
      `Every episode of ${loaderData.seriesTitle} ${loaderData.name}, with air dates, synopses and ratings.`;
    const image = backdropUrl(loaderData.seriesBackdropPath, "w1280");
    const meta = [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "video.tv_show" },
      { name: "twitter:card", content: "summary_large_image" },
    ];
    if (image) {
      meta.push({ property: "og:image", content: image }, { name: "twitter:image", content: image });
    }
    return { meta };
  },
  component: SeasonPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">That season doesn't exist.</p>
  ),
});

function SeasonPage() {
  const season: SeasonDetail = Route.useLoaderData();
  const poster = posterUrl(season.posterPath ?? season.seriesPosterPath, "w342");

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <Link
        to="/series/$seriesId"
        params={{ seriesId: String(season.seriesId) }}
        className="inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ChevronLeft className="h-4 w-4" aria-hidden />
        {season.seriesTitle}
      </Link>

      <header className="mt-6 grid gap-6 sm:grid-cols-[160px_minmax(0,1fr)]">
        {poster ? (
          <img
            src={poster}
            alt={`${season.name} poster`}
            className="w-40 rounded-2xl border border-border shadow-cinema"
          />
        ) : (
          <div className="aspect-[2/3] w-40 rounded-2xl bg-surface" />
        )}
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
            {season.seriesTitle}
          </p>
          <h1 className="mt-2 font-display text-4xl uppercase leading-none sm:text-5xl">
            {season.name}
          </h1>
          <p className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <CalendarDays className="h-4 w-4" aria-hidden />
              {releaseYear(season.airDate)}
            </span>
            <span>{season.episodes.length} episodes</span>
          </p>
          {season.overview ? (
            <p className="mt-4 max-w-3xl text-sm leading-relaxed text-muted-foreground">
              {season.overview}
            </p>
          ) : null}
        </div>
      </header>

      <h2 className="mb-4 mt-12 font-display text-2xl uppercase tracking-wide sm:text-3xl">
        Episodes
      </h2>

      {season.episodes.length ? (
        <ul className="space-y-4">
          {season.episodes.map((episode) => {
            const still = stillUrl(episode.stillPath, "w300");
            return (
              <li key={episode.id}>
                <Link
                  to="/series/$seriesId/season/$seasonNumber/episode/$episodeNumber"
                  params={{
                    seriesId: String(season.seriesId),
                    seasonNumber: String(season.seasonNumber),
                    episodeNumber: String(episode.episodeNumber),
                  }}
                  className="glass-panel grid gap-4 rounded-2xl p-4 transition-colors hover:border-primary/50 sm:grid-cols-[220px_minmax(0,1fr)]"
                >
                  {still ? (
                    <img
                      src={still}
                      alt=""
                      loading="lazy"
                      className="aspect-video w-full rounded-xl object-cover"
                    />
                  ) : (
                    <div className="aspect-video w-full rounded-xl bg-surface" />
                  )}
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="rounded-full bg-surface px-2.5 py-1 text-xs font-semibold text-muted-foreground">
                        E{episode.episodeNumber}
                      </span>
                      <h3 className="min-w-0 truncate text-base font-semibold">{episode.name}</h3>
                      {episode.voteCount ? (
                        <span className="inline-flex items-center gap-1 text-xs font-semibold text-gold">
                          <Star className="h-3 w-3 fill-current" aria-hidden />
                          {episode.voteAverage.toFixed(1)}
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {episode.airDate ?? "Air date TBA"}
                      {episode.runtime ? ` · ${episode.runtime}m` : ""}
                    </p>
                    <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">
                      {episode.overview || "No episode synopsis available yet."}
                    </p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="rounded-2xl border border-dashed border-border p-12 text-center text-sm text-muted-foreground">
          No episodes have been listed for this season yet.
        </p>
      )}
    </div>
  );
}
