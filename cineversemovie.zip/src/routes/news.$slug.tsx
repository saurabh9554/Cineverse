import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

import { getNewsArticle, type NewsArticle } from "@/lib/news.functions";

export const Route = createFileRoute("/news/$slug")({
  loader: async ({ params }) => {
    const article = await getNewsArticle({ data: { slug: params.slug } });
    if (!article) throw notFound();
    return article;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Story unavailable — CineVerse AI" }, { name: "robots", content: "noindex" }],
      };
    }
    const meta = [
      { title: `${loaderData.title} — CineVerse AI` },
      { name: "description", content: loaderData.excerpt },
      { property: "og:title", content: loaderData.title },
      { property: "og:description", content: loaderData.excerpt },
      { property: "og:type", content: "article" },
    ];
    if (loaderData.coverImageUrl?.startsWith("https://")) {
      meta.push(
        { property: "og:image", content: loaderData.coverImageUrl },
        { name: "twitter:image", content: loaderData.coverImageUrl },
      );
    }
    return { meta };
  },
  component: ArticlePage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <div className="px-4 py-32 text-center">
      <p className="text-sm text-muted-foreground">This story doesn't exist or was unpublished.</p>
      <Link to="/news" className="mt-4 inline-block text-sm text-primary underline">
        Back to news
      </Link>
    </div>
  ),
});

function ArticlePage() {
  const article: NewsArticle = Route.useLoaderData();

  return (
    <article className="mx-auto max-w-3xl px-4 pb-24 pt-28 sm:px-6">
      <Link
        to="/news"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" aria-hidden /> All stories
      </Link>

      <span className="mt-8 block text-xs font-semibold uppercase tracking-[0.25em] text-primary">
        {article.category}
      </span>
      <h1 className="mt-3 font-display text-4xl uppercase leading-none sm:text-5xl">
        {article.title}
      </h1>
      {article.publishedAt ? (
        <time dateTime={article.publishedAt} className="mt-3 block text-sm text-muted-foreground">
          {new Date(article.publishedAt).toLocaleDateString(undefined, { dateStyle: "long" })}
        </time>
      ) : null}

      {article.coverImageUrl ? (
        <img
          src={article.coverImageUrl}
          alt=""
          className="mt-8 aspect-video w-full rounded-2xl object-cover"
        />
      ) : null}

      <p className="mt-8 text-lg text-muted-foreground">{article.excerpt}</p>

      <div className="mt-6 space-y-4 text-base leading-relaxed">
        {article.content
          .split(/\n{2,}/)
          .filter(Boolean)
          .map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
      </div>
    </article>
  );
}
