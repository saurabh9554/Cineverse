import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import { z } from "zod";

import { PageHeader } from "@/components/common/PageHeader";
import { Pager } from "@/components/common/Pager";
import { SetupNotice } from "@/components/common/SetupNotice";
import { MovieGrid } from "@/components/movie/MovieGrid";
import { FilterBar, type FilterValues } from "@/components/movie/FilterBar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { discoverMovies, getGenres, searchMovies } from "@/lib/tmdb.functions";
import type { Genre, PagedMovies } from "@/lib/tmdb.types";
import type { DataResult } from "@/lib/data-result";

const CURRENT_YEAR = new Date().getFullYear() + 2;

const searchSchema = z.object({
  q: z.string().max(120).default(""),
  page: z.coerce.number().int().min(1).max(500).default(1),
  genres: z.array(z.coerce.number().int()).default([]),
  yearFrom: z.coerce.number().int().min(1950).max(CURRENT_YEAR).default(1950),
  yearTo: z.coerce.number().int().min(1950).max(CURRENT_YEAR).default(CURRENT_YEAR),
  minRating: z.coerce.number().min(0).max(9).default(0),
  sortBy: z.string().max(40).default("popularity.desc"),
});

type SearchParams = z.infer<typeof searchSchema>;

export const Route = createFileRoute("/search")({
  validateSearch: searchSchema,
  loaderDeps: ({ search }) => search,
  loader: async ({ deps }) => {
    const [genres, results] = await Promise.all([
      getGenres(),
      deps.q.trim()
        ? searchMovies({ data: { query: deps.q.trim(), page: deps.page } })
        : discoverMovies({
            data: {
              page: deps.page,
              genres: deps.genres,
              yearFrom: deps.yearFrom,
              yearTo: deps.yearTo,
              minRating: deps.minRating,
              sortBy: deps.sortBy,
              minVotes: deps.minRating > 0 ? 200 : 50,
            },
          }),
    ]);
    return { genres, results };
  },
  head: () => ({
    meta: [
      { title: "Search & Advanced Filters — CineVerse AI" },
      {
        name: "description",
        content:
          "Search thousands of films or filter by genre, release year, rating and sort order to find exactly what you want to watch.",
      },
      { property: "og:title", content: "Search & Advanced Filters — CineVerse AI" },
      {
        property: "og:description",
        content: "Search films or filter by genre, year, rating and sort order.",
      },
    ],
  }),
  component: SearchPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">No results.</p>
  ),
});

function SearchPage() {
  const { genres, results }: { genres: DataResult<Genre[]>; results: DataResult<PagedMovies> } =
    Route.useLoaderData();
  const search = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });
  const [term, setTerm] = useState(search.q);

  const filters: FilterValues = {
    genres: search.genres,
    yearFrom: search.yearFrom,
    yearTo: search.yearTo,
    minRating: search.minRating,
    sortBy: search.sortBy,
  };

  function update(next: Partial<FilterValues>) {
    navigate({ to: ".", search: (prev: SearchParams) => ({ ...prev, ...next, page: 1 }) });
  }

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Discovery"
        title={search.q ? `Results for “${search.q}”` : "Explore the catalogue"}
        description="Search by title or dial in the exact film you're after with advanced filters."
      />

      <form
        className="mb-8 flex gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          navigate({ to: ".", search: (prev: SearchParams) => ({ ...prev, q: term.trim(), page: 1 }) });
        }}
      >
        <div className="relative flex-1">
          <SearchIcon
            className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
            aria-hidden
          />
          <Input
            value={term}
            onChange={(event) => setTerm(event.target.value)}
            placeholder="Search films by title…"
            aria-label="Search films"
            className="h-12 rounded-full bg-surface pl-11 text-base"
          />
        </div>
        <Button type="submit" variant="hero" size="lg" className="shrink-0">
          Search
        </Button>
      </form>

      {!search.q ? (
        <div className="mb-10">
          <FilterBar
            genres={genres.ok ? genres.data : []}
            value={filters}
            onChange={update}
            onReset={() =>
              navigate({
                search: {
                  q: "",
                  page: 1,
                  genres: [],
                  yearFrom: 1950,
                  yearTo: CURRENT_YEAR,
                  minRating: 0,
                  sortBy: "popularity.desc",
                },
              })
            }
          />
        </div>
      ) : null}

      {results.ok ? (
        <div className="space-y-8">
          <p className="text-sm text-muted-foreground">
            {results.data.totalResults.toLocaleString()} films found
          </p>
          <MovieGrid movies={results.data.results} />
          <Pager
            page={search.page}
            totalPages={Math.min(results.data.totalPages, 500)}
            onPageChange={(next) => {
              navigate({ to: ".", search: (prev: SearchParams) => ({ ...prev, page: next }) });
              globalThis.window?.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </div>
      ) : (
        <SetupNotice result={results} />
      )}
    </div>
  );
}
