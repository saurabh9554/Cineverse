import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Clock, Play, Star } from "lucide-react";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { getEpisode } from "@/lib/tmdb.functions";
import { backdropUrl, profileUrl, stillUrl } from "@/lib/tmdb.types";
import type { EpisodeDetail } from "@/lib/tmdb.types";

export const Route = createFileRoute(
  "/series_/$seriesId/season/$seasonNumber/episode/$episodeNumber",
)({
  loader: async ({ params }) => {
    const seriesId = Number(params.seriesId);
    const seasonNumber = Number(params.seasonNumber);
    const episodeNumber = Number(params.episodeNumber);
    if (
      !Number.isInteger(seriesId) ||
      seriesId <= 0 ||
      !Number.isInteger(seasonNumber) ||
      !Number.isInteger(episodeNumber)
    ) {
      throw notFound();
    }
    const result = await getEpisode({ data: { seriesId, seasonNumber, episodeNumber } });
    if (!result.ok) throw new Error(result.message);
    return result.data;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Episode unavailable — CineVerse AI" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const label = `S${loaderData.seasonNumber}E${loaderData.episodeNumber}`;
    const title = `${loaderData.seriesTitle} ${label}: ${loaderData.name} — CineVerse AI`;
    const description =
      loaderData.overview?.slice(0, 155) ||
      `Cast, crew, air date and trailer for ${loaderData.seriesTitle} ${label}.`;
    const image =
      stillUrl(loaderData.stillPath, "w780") ?? backdropUrl(loaderData.seriesBackdropPath, "w1280");
    const meta = [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "video.episode" },
      { name: "twitter:card", content: "summary_large_image" },
    ];
    if (image) {
      meta.push({ property: "og:image", content: image }, { name: "twitter:image", content: image });
    }
    return { meta };
  },
  component: EpisodePage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">
      That episode doesn't exist.
    </p>
  ),
});

function EpisodePage() {
  const episode: EpisodeDetail = Route.useLoaderData();
  const [trailerOpen, setTrailerOpen] = useState(false);
  const hero = stillUrl(episode.stillPath, "w780") ?? backdropUrl(episode.seriesBackdropPath, "w1280");
  const seasonParams = {
    seriesId: String(episode.seriesId),
    seasonNumber: String(episode.seasonNumber),
  };

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "TVEpisode",
    name: episode.name,
    episodeNumber: episode.episodeNumber,
    description: episode.overview,
    datePublished: episode.airDate ?? undefined,
    image: hero ?? undefined,
    partOfSeries: { "@type": "TVSeries", name: episode.seriesTitle },
    partOfSeason: { "@type": "TVSeason", seasonNumber: episode.seasonNumber },
  };

  return (
    <div className="mx-auto max-w-5xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <nav className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
        <Link
          to="/series/$seriesId"
          params={{ seriesId: String(episode.seriesId) }}
          className="transition-colors hover:text-foreground"
        >
          {episode.seriesTitle}
        </Link>
        <ChevronRight className="h-3 w-3" aria-hidden />
        <Link
          to="/series/$seriesId/season/$seasonNumber"
          params={seasonParams}
          className="transition-colors hover:text-foreground"
        >
          {episode.seasonName}
        </Link>
        <ChevronRight className="h-3 w-3" aria-hidden />
        <span className="text-foreground">Episode {episode.episodeNumber}</span>
      </nav>

      {hero ? (
        <img
          src={hero}
          alt={`Still from ${episode.name}`}
          className="mt-6 aspect-video w-full rounded-2xl border border-border object-cover shadow-cinema"
        />
      ) : null}

      <header className="mt-8">
        <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
          Season {episode.seasonNumber} · Episode {episode.episodeNumber} of {episode.totalEpisodes}
        </p>
        <h1 className="mt-2 font-display text-3xl uppercase leading-none sm:text-5xl">
          {episode.name}
        </h1>
        <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
          {episode.voteCount ? (
            <span className="inline-flex items-center gap-1 font-semibold text-gold">
              <Star className="h-4 w-4 fill-current" aria-hidden />
              {episode.voteAverage.toFixed(1)}
              <span className="font-normal text-muted-foreground">
                ({episode.voteCount.toLocaleString()})
              </span>
            </span>
          ) : null}
          <span>{episode.airDate ?? "Air date TBA"}</span>
          {episode.runtime ? (
            <span className="inline-flex items-center gap-1">
              <Clock className="h-4 w-4" aria-hidden />
              {episode.runtime}m
            </span>
          ) : null}
        </div>

        <p className="mt-6 max-w-3xl text-base leading-relaxed text-muted-foreground">
          {episode.overview || "No episode synopsis is available yet."}
        </p>

        {episode.trailer ? (
          <button
            onClick={() => setTrailerOpen(true)}
            className="mt-7 inline-flex h-11 items-center gap-2 rounded-full bg-gradient-primary px-7 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.03]"
          >
            <Play className="h-4 w-4 fill-current" aria-hidden />
            Watch {episode.trailer.type.toLowerCase()}
          </button>
        ) : null}
      </header>

      {episode.videos.length ? (
        <section className="mt-10">
          <h2 className="mb-3 font-display text-xl uppercase tracking-wide">Video links</h2>
          <ul className="flex flex-wrap gap-2">
            {episode.videos.map((video) => (
              <li key={video.key}>
                <a
                  href={`https://www.youtube.com/watch?v=${video.key}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glass-panel inline-flex max-w-xs items-center gap-2 rounded-full px-4 py-2 text-sm transition-colors hover:border-primary/50"
                >
                  <Play className="h-3.5 w-3.5 shrink-0 fill-current text-primary" aria-hidden />
                  <span className="truncate">{video.name}</span>
                </a>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <PeopleRow title="Guest stars" people={episode.guestStars} />
      <PeopleRow title="Series cast in this episode" people={episode.cast} />

      {episode.crew.length ? (
        <section className="mt-10">
          <h2 className="mb-3 font-display text-xl uppercase tracking-wide">Crew</h2>
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {episode.crew.map((member) => (
              <li key={`${member.id}-${member.job}`} className="glass-panel rounded-xl px-4 py-3">
                <p className="truncate text-sm font-semibold">{member.name}</p>
                <p className="text-xs text-muted-foreground">{member.job}</p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {episode.images.length ? (
        <section className="mt-10">
          <h2 className="mb-3 font-display text-xl uppercase tracking-wide">Stills</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {episode.images.map((path) => (
              <img
                key={path}
                src={stillUrl(path, "w780") ?? ""}
                alt={`Still from ${episode.name}`}
                loading="lazy"
                className="aspect-video w-full rounded-xl border border-border object-cover"
              />
            ))}
          </div>
        </section>
      ) : null}

      <nav className="mt-12 flex flex-wrap items-center justify-between gap-3">
        {episode.previousEpisode ? (
          <Link
            to="/series/$seriesId/season/$seasonNumber/episode/$episodeNumber"
            params={{ ...seasonParams, episodeNumber: String(episode.previousEpisode) }}
            className="glass-panel inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm transition-colors hover:border-primary/50"
          >
            <ChevronLeft className="h-4 w-4" aria-hidden />
            Episode {episode.previousEpisode}
          </Link>
        ) : (
          <span />
        )}
        {episode.nextEpisode ? (
          <Link
            to="/series/$seriesId/season/$seasonNumber/episode/$episodeNumber"
            params={{ ...seasonParams, episodeNumber: String(episode.nextEpisode) }}
            className="glass-panel inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm transition-colors hover:border-primary/50"
          >
            Episode {episode.nextEpisode}
            <ChevronRight className="h-4 w-4" aria-hidden />
          </Link>
        ) : null}
      </nav>

      <Dialog open={trailerOpen} onOpenChange={setTrailerOpen}>
        <DialogContent className="max-w-4xl border-border bg-card p-0">
          <DialogHeader className="px-6 pt-6">
            <DialogTitle className="font-display text-2xl uppercase">{episode.name}</DialogTitle>
          </DialogHeader>
          <div className="aspect-video w-full overflow-hidden rounded-b-lg bg-surface">
            {episode.trailer ? (
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${episode.trailer.key}?autoplay=1&rel=0`}
                title={`${episode.name} trailer`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="h-full w-full border-0"
              />
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function PeopleRow({
  title,
  people,
}: {
  title: string;
  people: EpisodeDetail["cast"];
}) {
  if (!people.length) return null;
  return (
    <section className="mt-10">
      <h2 className="mb-3 font-display text-xl uppercase tracking-wide">{title}</h2>
      <div className="flex gap-4 overflow-x-auto pb-4">
        {people.map((member) => (
          <figure key={`${member.id}-${member.character}`} className="w-28 shrink-0">
            <Link to="/person/$personId" params={{ personId: String(member.id) }} className="block">
              {profileUrl(member.profilePath) ? (
                <img
                  src={profileUrl(member.profilePath)!}
                  alt={member.name}
                  loading="lazy"
                  className="aspect-[2/3] w-full rounded-xl object-cover transition-transform duration-200 hover:scale-105"
                />
              ) : (
                <div className="aspect-[2/3] w-full rounded-xl bg-surface" />
              )}
              <figcaption className="mt-2">
                <span className="block truncate text-sm font-medium">{member.name}</span>
                <span className="block truncate text-xs text-muted-foreground">
                  {member.character}
                </span>
              </figcaption>
            </Link>
          </figure>
        ))}
      </div>
    </section>
  );
}
