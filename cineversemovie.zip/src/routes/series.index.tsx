import { createFileRoute, Link } from "@tanstack/react-router";
import { Play, Star } from "lucide-react";

import { PageHeader } from "@/components/common/PageHeader";
import { SetupNotice } from "@/components/common/SetupNotice";
import { MovieRow } from "@/components/movie/MovieRow";
import { getSeriesHub } from "@/lib/tmdb.functions";
import { backdropUrl, releaseYear } from "@/lib/tmdb.types";

export const Route = createFileRoute("/series/")({
  loader: () => getSeriesHub(),
  head: () => ({
    meta: [
      { title: "Web Series & TV Shows — CineVerse AI" },
      {
        name: "description",
        content:
          "Binge the best web series and TV shows: trending, top rated, currently airing and Indian originals with trailers, cast and streaming info.",
      },
      { property: "og:title", content: "Web Series & TV Shows — CineVerse AI" },
      {
        property: "og:description",
        content:
          "Trending, top rated and currently airing web series with trailers, cast and streaming availability.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SeriesHubPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
});

function SeriesHubPage() {
  const result = Route.useLoaderData();

  if (!result.ok) {
    return (
      <div className="px-4 py-32">
        <SetupNotice result={result} />
      </div>
    );
  }

  const hub = result.data;
  const featured = hub.hero[0];

  return (
    <div className="pb-24">
      {featured ? (
        <section className="relative">
          <img
            src={backdropUrl(featured.backdropPath, "original") ?? ""}
            alt=""
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/90 to-background/50" />
          <div className="relative mx-auto max-w-7xl px-4 pb-16 pt-36 sm:px-6 lg:px-8">
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
              Featured series
            </p>
            <h1 className="mt-3 max-w-3xl font-display text-4xl uppercase leading-none sm:text-6xl">
              {featured.title}
            </h1>
            <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1 font-semibold text-gold">
                <Star className="h-4 w-4 fill-current" aria-hidden />
                {featured.voteAverage.toFixed(1)}
              </span>
              <span>{releaseYear(featured.releaseDate)}</span>
            </div>
            <p className="mt-4 max-w-2xl line-clamp-3 text-sm text-muted-foreground">
              {featured.overview}
            </p>
            <Link
              to="/series/$seriesId"
              params={{ seriesId: String(featured.id) }}
              className="mt-7 inline-flex h-11 items-center gap-2 rounded-full bg-gradient-primary px-7 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.03]"
            >
              <Play className="h-4 w-4 fill-current" aria-hidden />
              Explore series
            </Link>
          </div>
        </section>
      ) : (
        <div className="mx-auto max-w-7xl px-4 pt-28 sm:px-6 lg:px-8">
          <PageHeader
            eyebrow="Binge worthy"
            title="Web Series"
            description="The best shows streaming right now, across the world."
          />
        </div>
      )}

      <div className="mx-auto max-w-7xl space-y-14 px-4 pt-14 sm:px-6 lg:px-8">
        <MovieRow
          title="Trending series this week"
          subtitle="What the world is binge-watching"
          movies={hub.trending}
          mediaType="tv"
        />
        <MovieRow title="Airing today" movies={hub.airingToday} mediaType="tv" />
        <MovieRow title="Currently on the air" movies={hub.onTheAir} mediaType="tv" />
        <MovieRow title="Popular web series" movies={hub.popular} mediaType="tv" />
        <MovieRow title="Highest rated of all time" movies={hub.topRated} mediaType="tv" />
        <MovieRow title="Indian originals" movies={hub.indian} mediaType="tv" />
      </div>
    </div>
  );
}
