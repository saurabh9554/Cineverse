import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Clock, Layers, Play, Star, TrendingUp } from "lucide-react";

import { MovieRow } from "@/components/movie/MovieRow";
import { RatingsPanel } from "@/components/movie/RatingsPanel";
import { ReleaseDatesPanel } from "@/components/movie/ReleaseDatesPanel";
import { AwardsPanel } from "@/components/movie/AwardsPanel";
import { StreamingPanel } from "@/components/movie/StreamingPanel";
import { TrailerDialog } from "@/components/movie/TrailerDialog";
import { WatchlistButton } from "@/components/movie/WatchlistButton";
import { ReviewSection } from "@/components/movie/ReviewSection";

import { Badge } from "@/components/ui/badge";
import { getMovieDetail } from "@/lib/tmdb.functions";
import {
  backdropUrl,
  formatCurrency,
  formatRuntime,
  posterUrl,
  profileUrl,
  releaseYear,
} from "@/lib/tmdb.types";
import type { MovieDetail } from "@/lib/tmdb.types";

export const Route = createFileRoute("/movie/$movieId")({
  loader: async ({ params }) => {
    const id = Number(params.movieId);
    if (!Number.isInteger(id) || id <= 0) throw notFound();
    const result = await getMovieDetail({ data: { id } });
    if (!result.ok) throw new Error(result.message);
    return result.data;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Film unavailable — CineVerse AI" }, { name: "robots", content: "noindex" }] };
    }
    const title = `${loaderData.title} (${releaseYear(loaderData.releaseDate)}) — CineVerse AI`;
    const description =
      loaderData.overview?.slice(0, 155) || `Cast, ratings, trailers and reviews for ${loaderData.title}.`;
    const image = backdropUrl(loaderData.backdropPath, "w1280");
    const meta = [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "video.movie" },
    ];
    if (image) {
      meta.push({ property: "og:image", content: image }, { name: "twitter:image", content: image });
    }
    return { meta };
  },
  component: MovieDetailPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">That film doesn't exist.</p>
  ),
});

function MovieDetailPage() {
  const movie: MovieDetail = Route.useLoaderData();
  const [trailerOpen, setTrailerOpen] = useState(false);
  const backdrop = backdropUrl(movie.backdropPath, "original");
  const poster = posterUrl(movie.posterPath, "w500");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Movie",
    name: movie.title,
    description: movie.overview,
    image: poster ?? undefined,
    datePublished: movie.releaseDate ?? undefined,
    genre: movie.genres.map((g) => g.name),
    aggregateRating: movie.voteCount
      ? {
          "@type": "AggregateRating",
          ratingValue: movie.voteAverage.toFixed(1),
          ratingCount: movie.voteCount,
          bestRating: 10,
          worstRating: 0,
        }
      : undefined,
    actor: movie.cast.slice(0, 6).map((c) => ({ "@type": "Person", name: c.name })),
  };

  return (
    <div className="pb-24">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <div className="relative">
        {backdrop ? (
          <img
            src={backdrop}
            alt=""
            className="absolute inset-0 h-full w-full object-cover object-top"
          />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/92 to-background/60" />

        <div className="relative mx-auto max-w-7xl px-4 pb-12 pt-32 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-[280px_minmax(0,1fr)]">
            <div className="mx-auto w-48 shrink-0 md:mx-0 md:w-full">
              {poster ? (
                <img
                  src={poster}
                  alt={`${movie.title} poster`}
                  width={500}
                  height={750}
                  className="w-full rounded-2xl border border-border shadow-cinema"
                />
              ) : (
                <div className="aspect-[2/3] w-full rounded-2xl bg-surface" />
              )}
            </div>

            <div className="min-w-0">
              <h1 className="font-display text-4xl uppercase leading-none sm:text-6xl">
                {movie.title}
              </h1>
              {movie.tagline ? (
                <p className="mt-2 text-lg italic text-muted-foreground">{movie.tagline}</p>
              ) : null}

              <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1 font-semibold text-gold">
                  <Star className="h-4 w-4 fill-current" aria-hidden />
                  {movie.voteAverage.toFixed(1)}
                  <span className="font-normal text-muted-foreground">
                    ({movie.voteCount.toLocaleString()})
                  </span>
                </span>
                <span>{releaseYear(movie.releaseDate)}</span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-4 w-4" aria-hidden />
                  {formatRuntime(movie.runtime)}
                </span>
                {movie.omdb?.rated ? <span>Rated {movie.omdb.rated}</span> : null}
                <span className="inline-flex items-center gap-1">
                  <TrendingUp className="h-4 w-4" aria-hidden />
                  {Math.round(movie.popularity)}
                </span>
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {movie.genres.map((genre) => (
                  <Badge key={genre.id} variant="secondary">
                    {genre.name}
                  </Badge>
                ))}
              </div>

              <p className="mt-6 max-w-3xl text-base leading-relaxed text-muted-foreground">
                {movie.overview || "No synopsis available yet."}
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                {movie.trailer ? (
                  <button
                    onClick={() => setTrailerOpen(true)}
                    className="inline-flex h-11 items-center gap-2 rounded-full bg-gradient-primary px-7 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.03]"
                  >
                    <Play className="h-4 w-4 fill-current" aria-hidden /> Watch trailer
                  </button>
                ) : null}
                <WatchlistButton movie={movie} />
              </div>
              <TrailerDialog
                movieId={trailerOpen ? movie.id : null}
                onOpenChange={(open) => setTrailerOpen(open)}
              />
              <RatingsPanel movie={movie} />

              <dl className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
                <Stat label="Status" value={movie.status ?? "—"} />
                <Stat label="Budget" value={formatCurrency(movie.budget)} />
                <Stat
                  label="Box office"
                  value={movie.omdb?.boxOffice ?? formatCurrency(movie.revenue)}
                />
                <Stat
                  label="Language"
                  value={movie.spokenLanguages[0] ?? movie.originalLanguage.toUpperCase()}
                />
              </dl>

              {movie.collection ? (
                <Link
                  to="/collection/$collectionId"
                  params={{ collectionId: String(movie.collection.id) }}
                  className="mt-6 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-sm font-medium transition-colors hover:border-primary/60"
                >
                  <Layers className="h-4 w-4" aria-hidden />
                  Part of {movie.collection.name} · {movie.collection.parts.length} films
                </Link>
              ) : null}

              {movie.keywords.length ? (
                <ul className="mt-6 flex flex-wrap gap-2" aria-label="Themes">
                  {movie.keywords.map((keyword) => (
                    <li
                      key={keyword}
                      className="rounded-full bg-surface px-3 py-1 text-xs text-muted-foreground"
                    >
                      {keyword}
                    </li>
                  ))}
                </ul>
              ) : null}

            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl space-y-14 px-4 sm:px-6 lg:px-8">
        {movie.cast.length ? (
          <section>
            <h2 className="mb-4 font-display text-2xl uppercase tracking-wide sm:text-3xl">
              Top billed cast
            </h2>
            <div className="flex gap-4 overflow-x-auto pb-4">
              {movie.cast.map((member) => (
                <figure key={`${member.id}-${member.character}`} className="w-32 shrink-0">
                  <Link
                    to="/person/$personId"
                    params={{ personId: String(member.id) }}
                    className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                  >
                    {profileUrl(member.profilePath) ? (
                      <img
                        src={profileUrl(member.profilePath)!}
                        alt={member.name}
                        loading="lazy"
                        width={185}
                        height={278}
                        className="aspect-[2/3] w-full rounded-xl object-cover transition-transform duration-200 hover:scale-105"
                      />
                    ) : (
                      <div className="aspect-[2/3] w-full rounded-xl bg-surface" />
                    )}
                    <figcaption className="mt-2">
                      <span className="block truncate text-sm font-medium">{member.name}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {member.character}
                      </span>
                    </figcaption>
                  </Link>
                </figure>
              ))}
            </div>
          </section>
        ) : null}

        <ReleaseDatesPanel releases={movie.releases} />

        <AwardsPanel awards={movie.omdb?.awards} title={movie.title} />

        {movie.providers ? <StreamingPanel providers={movie.providers} /> : null}

        {movie.images.length ? (
          <section>
            <h2 className="mb-4 font-display text-2xl uppercase tracking-wide sm:text-3xl">
              Gallery
            </h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {movie.images.map((path) => (
                <img
                  key={path}
                  src={backdropUrl(path, "w780") ?? ""}
                  alt={`Still from ${movie.title}`}
                  loading="lazy"
                  className="aspect-video w-full rounded-xl border border-border object-cover"
                />
              ))}
            </div>
          </section>
        ) : null}

        <ReviewSection movieId={movie.id} movieTitle={movie.title} />


        <MovieRow title="More like this" movies={movie.recommendations.length ? movie.recommendations : movie.similar} />
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-card/60 p-4">
      <dt className="text-xs uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="mt-1 truncate text-lg font-semibold">{value}</dd>
    </div>
  );
}
