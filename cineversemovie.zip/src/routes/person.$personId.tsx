import { createFileRoute, notFound } from "@tanstack/react-router";

import { MovieGrid } from "@/components/movie/MovieGrid";
import { PageHeader } from "@/components/common/PageHeader";
import { getPerson } from "@/lib/tmdb.functions";
import { profileUrl } from "@/lib/tmdb.types";
import type { PersonDetail } from "@/lib/tmdb.types";

export const Route = createFileRoute("/person/$personId")({
  loader: async ({ params }) => {
    const id = Number(params.personId);
    if (!Number.isInteger(id) || id <= 0) throw notFound();
    const result = await getPerson({ data: { id } });
    if (!result.ok) throw new Error(result.message);
    return result.data;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Profile unavailable — CineVerse AI" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.name} — Filmography & Biography | CineVerse AI`;
    const description =
      loaderData.biography.slice(0, 155) ||
      `Explore the complete filmography of ${loaderData.name} on CineVerse AI.`;
    const image = profileUrl(loaderData.profilePath);
    const meta = [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "profile" },
      { name: "twitter:card", content: "summary_large_image" },
    ];
    if (image) {
      meta.push({ property: "og:image", content: image }, { name: "twitter:image", content: image });
    }
    return { meta };
  },
  component: PersonPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">That profile doesn't exist.</p>
  ),
});

function PersonPage() {
  const person: PersonDetail = Route.useLoaderData();
  const photo = profileUrl(person.profilePath);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: person.name,
    description: person.biography || undefined,
    image: photo ?? undefined,
    birthDate: person.birthday ?? undefined,
    birthPlace: person.placeOfBirth ?? undefined,
    jobTitle: person.knownFor ?? undefined,
  };

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="grid gap-8 md:grid-cols-[220px_minmax(0,1fr)]">
        <div className="mx-auto w-40 shrink-0 md:mx-0 md:w-full">
          {photo ? (
            <img
              src={photo}
              alt={person.name}
              width={185}
              height={278}
              className="w-full rounded-2xl border border-border object-cover shadow-cinema"
            />
          ) : (
            <div className="aspect-[2/3] w-full rounded-2xl bg-surface" />
          )}
        </div>

        <div className="min-w-0">
          <PageHeader
            eyebrow={person.knownFor ?? "Filmmaker"}
            title={person.name}
            description={
              [person.birthday && `Born ${person.birthday}`, person.placeOfBirth]
                .filter(Boolean)
                .join(" · ") || undefined
            }
          />
          {person.biography ? (
            <p className="max-w-3xl whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
              {person.biography}
            </p>
          ) : null}
        </div>
      </div>

      {person.acting.length ? (
        <section className="mt-16">
          <h2 className="mb-6 font-display text-2xl uppercase tracking-wide sm:text-3xl">
            Acting credits
          </h2>
          <MovieGrid movies={person.acting} />
        </section>
      ) : null}

      {person.directing.length ? (
        <section className="mt-16">
          <h2 className="mb-6 font-display text-2xl uppercase tracking-wide sm:text-3xl">
            Behind the camera
          </h2>
          <MovieGrid movies={person.directing} />
        </section>
      ) : null}
    </div>
  );
}
