import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { z } from "zod";

import { PageHeader } from "@/components/common/PageHeader";
import { Pager } from "@/components/common/Pager";
import { SetupNotice } from "@/components/common/SetupNotice";
import { MovieGrid } from "@/components/movie/MovieGrid";
import { getCategory } from "@/lib/tmdb.functions";

const searchSchema = z.object({
  page: z.coerce.number().int().min(1).max(500).default(1),
});

export const Route = createFileRoute("/top-rated")({
  validateSearch: searchSchema,
  loaderDeps: ({ search }) => ({ page: search.page }),
  loader: ({ deps }) => getCategory({ data: { category: "top_rated", page: deps.page } }),
  head: () => ({
    meta: [
      { title: "Top Rated Movies of All Time — CineVerse AI" },
      {
        name: "description",
        content: "The highest rated films ever made, ranked by audience score across hundreds of thousands of votes.",
      },
      { property: "og:title", content: "Top Rated Movies of All Time — CineVerse AI" },
      {
        property: "og:description",
        content: "The highest rated films ever made, ranked by audience score.",
      },
    ],
  }),
  component: TopRatedPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">No films found.</p>
  ),
});

function TopRatedPage() {
  const result = Route.useLoaderData();
  const { page } = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Hall of fame"
        title="Top rated"
        description="Consensus classics and modern masterpieces, sorted by audience score."
      />

      {result.ok ? (
        <div className="space-y-8">
          <MovieGrid movies={result.data.results} />
          <Pager
            page={page}
            totalPages={result.data.totalPages}
            onPageChange={(next) => {
              navigate({ search: { page: next } });
              globalThis.window?.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </div>
      ) : (
        <SetupNotice result={result} />
      )}
    </div>
  );
}
