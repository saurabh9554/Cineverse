import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";

import { PageHeader } from "@/components/common/PageHeader";
import { Pager } from "@/components/common/Pager";
import { SetupNotice } from "@/components/common/SetupNotice";
import { MovieGrid } from "@/components/movie/MovieGrid";
import { getTvCategory } from "@/lib/tmdb.functions";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { value: "popular", label: "Popular" },
  { value: "top_rated", label: "Top rated" },
  { value: "on_the_air", label: "On the air" },
  { value: "airing_today", label: "Airing today" },
] as const;

const searchSchema = z.object({
  page: z.coerce.number().int().min(1).max(500).default(1),
  category: z.enum(["popular", "top_rated", "on_the_air", "airing_today"]).default("popular"),
});

export const Route = createFileRoute("/tv-shows")({
  validateSearch: searchSchema,
  loaderDeps: ({ search }) => ({ page: search.page, category: search.category }),
  loader: ({ deps }) => getTvCategory({ data: { category: deps.category, page: deps.page } }),
  head: () => ({
    meta: [
      { title: "TV Shows — Popular, Top Rated & Airing Now | CineVerse AI" },
      {
        name: "description",
        content:
          "Browse every TV show: popular, top rated, currently on the air and airing today, with ratings, air dates, cast and streaming availability.",
      },
      { property: "og:title", content: "TV Shows — Popular, Top Rated & Airing Now" },
      {
        property: "og:description",
        content: "The full TV listing: popular, top rated, on the air and airing today.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TvShowsPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
});

function TvShowsPage() {
  const result = Route.useLoaderData();
  const { page, category } = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Television"
        title="TV shows"
        description="Every show worth your evening — popular hits, all-time greats and everything airing right now."
      />

      <nav aria-label="TV categories" className="mb-8 flex flex-wrap gap-2">
        {CATEGORIES.map((item) => (
          <Link
            key={item.value}
            to="/tv-shows"
            search={{ category: item.value, page: 1 }}
            className={cn(
              "rounded-full border px-4 py-2 text-sm font-medium transition-colors",
              item.value === category
                ? "border-primary bg-gradient-primary text-primary-foreground"
                : "border-border text-muted-foreground hover:border-primary/60 hover:text-foreground",
            )}
          >
            {item.label}
          </Link>
        ))}
      </nav>

      {result.ok ? (
        <div className="space-y-8">
          <MovieGrid movies={result.data.results} mediaType="tv" />
          <Pager
            page={page}
            totalPages={result.data.totalPages}
            onPageChange={(next) => {
              navigate({ search: { category, page: next } });
              globalThis.window?.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </div>
      ) : (
        <SetupNotice result={result} />
      )}
    </div>
  );
}
