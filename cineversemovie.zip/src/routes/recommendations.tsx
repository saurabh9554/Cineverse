import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Loader2, Sparkles, Star } from "lucide-react";

import { PageHeader } from "@/components/common/PageHeader";
import { SetupNotice } from "@/components/common/SetupNotice";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { getAiRecommendations } from "@/lib/ai.functions";
import { useAuth } from "@/hooks/useAuth";
import { posterUrl, releaseYear } from "@/lib/tmdb.types";


const PRESETS = [
  "Mind-bending sci-fi that rewards a second watch",
  "Cosy feel-good films for a rainy Sunday",
  "Tense one-location thrillers under two hours",
  "Visually stunning animation for adults",
];

export const Route = createFileRoute("/recommendations")({
  head: () => ({
    meta: [
      { title: "AI Movie Recommendations — CineVerse AI" },
      {
        name: "description",
        content:
          "Describe the mood, era or vibe you're after and let the CineVerse AI curator build a personalised shortlist with reasons.",
      },
      { property: "og:title", content: "AI Movie Recommendations — CineVerse AI" },
      {
        property: "og:description",
        content: "Describe a mood and get a personalised, reasoned film shortlist.",
      },
    ],
  }),
  component: RecommendationsPage,
});

function RecommendationsPage() {
  const [prompt, setPrompt] = useState("");
  const { user, loading } = useAuth();
  const recommend = useServerFn(getAiRecommendations);

  const mutation = useMutation({
    mutationFn: (value: string) => recommend({ data: { prompt: value, seedTitles: [] } }),
  });

  const result = mutation.data;
  const signedIn = Boolean(user);


  return (
    <div className="mx-auto max-w-6xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="CineVerse AI"
        title="AI curator"
        description="Tell the curator what you're in the mood for — a feeling, a director, a decade, a double bill — and get a reasoned shortlist."
      />

      {!signedIn && !loading ? (
        <div className="space-y-4 rounded-2xl border border-border bg-card p-6">
          <p className="text-sm text-muted-foreground">
            Sign in to use the AI curator — personalised shortlists are available to CineVerse
            members.
          </p>
          <Button asChild variant="hero" size="lg">
            <Link to="/auth">
              <Sparkles aria-hidden /> Sign in to continue
            </Link>
          </Button>
        </div>
      ) : (
        <form
          className="space-y-4 rounded-2xl border border-border bg-card p-6"
          onSubmit={(event) => {
            event.preventDefault();
            if (prompt.trim().length >= 3) mutation.mutate(prompt.trim());
          }}
        >
          <Textarea
            value={prompt}
            onChange={(event) => setPrompt(event.target.value)}
            rows={3}
            maxLength={400}
            aria-label="Describe what you want to watch"
            placeholder="e.g. Slow-burn detective films with great cinematography and a bleak ending"
            className="resize-none bg-surface text-base"
          />
          <div className="flex flex-wrap gap-2">
            {PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setPrompt(preset)}
                className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/60 hover:text-foreground"
              >
                {preset}
              </button>
            ))}
          </div>
          <Button
            type="submit"
            variant="hero"
            size="lg"
            disabled={mutation.isPending || loading || prompt.trim().length < 3}
          >
            {mutation.isPending ? (
              <>
                <Loader2 className="animate-spin" aria-hidden /> Curating…
              </>
            ) : (
              <>
                <Sparkles aria-hidden /> Get my shortlist
              </>
            )}
          </Button>
        </form>
      )}


      <div className="mt-10">
        {mutation.isError ? (
          <p className="text-sm text-destructive">
            The curator couldn't respond. Please try again in a moment.
          </p>
        ) : null}

        {result && !result.ok ? <SetupNotice result={result} /> : null}

        {result?.ok ? (
          result.data.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No matches this time — try describing the mood differently.
            </p>
          ) : (
            <ul className="space-y-4">
              {result.data.map((item) => (
                <li
                  key={`${item.title}-${item.movie?.id ?? item.year ?? ""}`}
                  className="flex gap-5 rounded-2xl border border-border bg-card p-5"
                >
                  {item.movie && posterUrl(item.movie.posterPath) ? (
                    <Link
                      to="/movie/$movieId"
                      params={{ movieId: String(item.movie.id) }}
                      className="shrink-0"
                    >
                      <img
                        src={posterUrl(item.movie.posterPath)!}
                        alt={item.title}
                        loading="lazy"
                        width={185}
                        height={278}
                        className="w-24 rounded-xl object-cover"
                      />
                    </Link>
                  ) : (
                    <div className="h-36 w-24 shrink-0 rounded-xl bg-surface" />
                  )}
                  <div className="min-w-0">
                    <h3 className="text-lg font-semibold">
                      {item.movie ? (
                        <Link
                          to="/movie/$movieId"
                          params={{ movieId: String(item.movie.id) }}
                          className="hover:text-primary"
                        >
                          {item.movie.title}
                        </Link>
                      ) : (
                        item.title
                      )}{" "}
                      <span className="text-sm font-normal text-muted-foreground">
                        {item.movie ? releaseYear(item.movie.releaseDate) : (item.year ?? "")}
                      </span>
                    </h3>
                    {item.movie ? (
                      <span className="mt-1 inline-flex items-center gap-1 text-sm text-gold">
                        <Star className="h-3.5 w-3.5 fill-current" aria-hidden />
                        {item.movie.voteAverage.toFixed(1)}
                      </span>
                    ) : null}
                    <p className="mt-2 text-sm text-muted-foreground">{item.reason}</p>
                  </div>
                </li>
              ))}
            </ul>
          )
        ) : null}
      </div>
    </div>
  );
}
