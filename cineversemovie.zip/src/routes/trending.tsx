import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { z } from "zod";

import { PageHeader } from "@/components/common/PageHeader";
import { Pager } from "@/components/common/Pager";
import { SetupNotice } from "@/components/common/SetupNotice";
import { MovieGrid } from "@/components/movie/MovieGrid";
import { getTrending } from "@/lib/tmdb.functions";
import { Button } from "@/components/ui/button";

const searchSchema = z.object({
  page: z.coerce.number().int().min(1).max(500).default(1),
  window: z.enum(["day", "week"]).default("week"),
});

export const Route = createFileRoute("/trending")({
  validateSearch: searchSchema,
  loaderDeps: ({ search }) => ({ page: search.page, window: search.window }),
  loader: ({ deps }) => getTrending({ data: deps }),
  head: () => ({
    meta: [
      { title: "Trending Movies — CineVerse AI" },
      {
        name: "description",
        content: "The films everyone is watching today and this week, ranked by real-time momentum.",
      },
      { property: "og:title", content: "Trending Movies — CineVerse AI" },
      {
        property: "og:description",
        content: "The films everyone is watching today and this week, ranked by real-time momentum.",
      },
    ],
  }),
  component: TrendingPage,
  errorComponent: ({ error }) => <ErrorState message={error.message} />,
  notFoundComponent: () => <ErrorState message="No trending films found." />,
});

function ErrorState({ message }: { message: string }) {
  return <p className="px-4 py-32 text-center text-sm text-muted-foreground">{message}</p>;
}

function TrendingPage() {
  const result = Route.useLoaderData();
  const { page, window } = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Live momentum"
        title="Trending"
        description="Ranked by how fast audiences are discovering, rating and saving each film."
        actions={
          <div className="flex gap-2">
            {(["day", "week"] as const).map((value) => (
              <Button
                key={value}
                size="sm"
                variant={window === value ? "hero" : "glass"}
                onClick={() => navigate({ search: { page: 1, window: value } })}
              >
                {value === "day" ? "Today" : "This week"}
              </Button>
            ))}
          </div>
        }
      />

      {result.ok ? (
        <div className="space-y-8">
          <MovieGrid movies={result.data.results} />
          <Pager
            page={page}
            totalPages={result.data.totalPages}
            onPageChange={(next) => {
              navigate({ search: { page: next, window } });
              globalThis.window?.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </div>
      ) : (
        <SetupNotice result={result} />
      )}
    </div>
  );
}
