import { createFileRoute, Link, notFound } from "@tanstack/react-router";

import { MovieRow } from "@/components/movie/MovieRow";
import { HeroBanner } from "@/components/movie/HeroBanner";
import { PageHeader } from "@/components/common/PageHeader";
import { findIndustry, INDUSTRIES } from "@/lib/industries";
import { getIndustry } from "@/lib/tmdb.functions";
import type { IndustryPayload } from "@/lib/tmdb.server";

export const Route = createFileRoute("/cinema/$industry")({
  loader: async ({ params }) => {
    const industry = findIndustry(params.industry);
    if (!industry) throw notFound();
    const result = await getIndustry({ data: { language: industry.language } });
    if (!result.ok) throw new Error(result.message);
    return { industry, payload: result.data };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Cinema hub unavailable — CineVerse AI" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.industry.name} Movies — CineVerse AI`;
    const description = `${loaderData.industry.tagline} Browse trending, top rated and upcoming ${loaderData.industry.name} films with ratings, trailers and streaming links.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: IndustryPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">
      We don't cover that cinema yet.
    </p>
  ),
});

function IndustryPage() {
  const { industry, payload }: { industry: ReturnType<typeof findIndustry>; payload: IndustryPayload } =
    Route.useLoaderData();
  if (!industry) return null;

  return (
    <div className="pb-24">
      {payload.hero.length ? <HeroBanner movies={payload.hero} /> : <div className="pt-24" />}

      <div className="mx-auto max-w-7xl space-y-14 px-4 pt-12 sm:px-6 lg:px-8">
        <PageHeader
          eyebrow="World cinema"
          title={`${industry.name} cinema`}
          description={industry.tagline}
        />

        <nav aria-label="Other film industries" className="flex flex-wrap gap-2">
          {INDUSTRIES.map((item) => (
            <Link
              key={item.slug}
              to="/cinema/$industry"
              params={{ industry: item.slug }}
              className="glass-panel rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground aria-[current=page]:text-foreground"
              activeProps={{ className: "text-foreground ring-1 ring-primary/50" }}
            >
              {item.name}
            </Link>
          ))}
        </nav>

        <MovieRow title="Trending now" movies={payload.trending} />
        <MovieRow title="Top rated of all time" movies={payload.topRated} />
        <MovieRow title="Coming soon" movies={payload.upcoming} />
        <MovieRow title="Modern classics" movies={payload.classics} />
      </div>
    </div>
  );
}
