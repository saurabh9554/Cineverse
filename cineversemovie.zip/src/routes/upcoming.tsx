import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { z } from "zod";

import { PageHeader } from "@/components/common/PageHeader";
import { Pager } from "@/components/common/Pager";
import { SetupNotice } from "@/components/common/SetupNotice";
import { MovieGrid } from "@/components/movie/MovieGrid";
import { getCategory } from "@/lib/tmdb.functions";

const searchSchema = z.object({
  page: z.coerce.number().int().min(1).max(500).default(1),
});

export const Route = createFileRoute("/upcoming")({
  validateSearch: searchSchema,
  loaderDeps: ({ search }) => ({ page: search.page }),
  loader: ({ deps }) => getCategory({ data: { category: "upcoming", page: deps.page } }),
  head: () => ({
    meta: [
      { title: "Upcoming Movie Releases — CineVerse AI" },
      {
        name: "description",
        content: "Every upcoming theatrical release worth tracking, with trailers and release dates.",
      },
      { property: "og:title", content: "Upcoming Movie Releases — CineVerse AI" },
      {
        property: "og:description",
        content: "Every upcoming theatrical release worth tracking, with trailers and release dates.",
      },
    ],
  }),
  component: UpcomingPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">Nothing scheduled yet.</p>
  ),
});

function UpcomingPage() {
  const result = Route.useLoaderData();
  const { page } = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });

  return (
    <div className="mx-auto max-w-7xl px-4 pb-24 pt-28 sm:px-6 lg:px-8">
      <PageHeader
        eyebrow="Coming soon"
        title="Upcoming"
        description="Release calendars, first trailers and the titles worth adding to your watchlist early."
      />

      {result.ok ? (
        <div className="space-y-8">
          <MovieGrid movies={result.data.results} emptyMessage="No upcoming films right now." />
          <Pager
            page={page}
            totalPages={result.data.totalPages}
            onPageChange={(next) => {
              navigate({ search: { page: next } });
              globalThis.window?.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        </div>
      ) : (
        <SetupNotice result={result} />
      )}
    </div>
  );
}
