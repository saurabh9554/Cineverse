import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { CalendarDays, Clock, Layers, Play, Star, Tv } from "lucide-react";

import { MovieRow } from "@/components/movie/MovieRow";
import { AwardsPanel } from "@/components/movie/AwardsPanel";
import { StreamingPanel } from "@/components/movie/StreamingPanel";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { getSeriesDetail } from "@/lib/tmdb.functions";
import { TMDB_IMAGE_BASE, backdropUrl, formatEpisodeRuntime, formatReleaseDate, posterUrl, profileUrl, releaseYear } from "@/lib/tmdb.types";
import type { TvDetail } from "@/lib/tmdb.types";

export const Route = createFileRoute("/series/$seriesId")({
  loader: async ({ params }) => {
    const id = Number(params.seriesId);
    if (!Number.isInteger(id) || id <= 0) throw notFound();
    const result = await getSeriesDetail({ data: { id } });
    if (!result.ok) throw new Error(result.message);
    return result.data;
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Series unavailable — CineVerse AI" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const title = `${loaderData.title} (${releaseYear(loaderData.firstAirDate)}) — CineVerse AI`;
    const description =
      loaderData.overview?.slice(0, 155) ||
      `Seasons, cast, ratings and trailers for the series ${loaderData.title}.`;
    const image = backdropUrl(loaderData.backdropPath, "w1280");
    const meta = [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "video.tv_show" },
      { name: "twitter:card", content: "summary_large_image" },
    ];
    if (image) {
      meta.push({ property: "og:image", content: image }, { name: "twitter:image", content: image });
    }
    return { meta };
  },
  component: SeriesDetailPage,
  errorComponent: ({ error }) => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">{error.message}</p>
  ),
  notFoundComponent: () => (
    <p className="px-4 py-32 text-center text-sm text-muted-foreground">That series doesn't exist.</p>
  ),
});

function SeriesDetailPage() {
  const series: TvDetail = Route.useLoaderData();
  const [trailerOpen, setTrailerOpen] = useState(false);
  const backdrop = backdropUrl(series.backdropPath, "original");
  const poster = posterUrl(series.posterPath, "w500");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "TVSeries",
    name: series.title,
    description: series.overview,
    image: poster ?? undefined,
    datePublished: series.firstAirDate ?? undefined,
    numberOfSeasons: series.numberOfSeasons,
    numberOfEpisodes: series.numberOfEpisodes,
    genre: series.genres.map((g) => g.name),
    aggregateRating: series.voteCount
      ? {
          "@type": "AggregateRating",
          ratingValue: series.voteAverage.toFixed(1),
          ratingCount: series.voteCount,
          bestRating: 10,
          worstRating: 0,
        }
      : undefined,
  };

  return (
    <div className="pb-24">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <div className="relative">
        {backdrop ? (
          <img src={backdrop} alt="" className="absolute inset-0 h-full w-full object-cover object-top" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/92 to-background/60" />

        <div className="relative mx-auto max-w-7xl px-4 pb-12 pt-32 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-[280px_minmax(0,1fr)]">
            <div className="mx-auto w-48 shrink-0 md:mx-0 md:w-full">
              {poster ? (
                <img
                  src={poster}
                  alt={`${series.title} poster`}
                  width={500}
                  height={750}
                  className="w-full rounded-2xl border border-border shadow-cinema"
                />
              ) : (
                <div className="aspect-[2/3] w-full rounded-2xl bg-surface" />
              )}
            </div>

            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
                Web series
              </p>
              <h1 className="mt-2 font-display text-4xl uppercase leading-none sm:text-6xl">
                {series.title}
              </h1>
              {series.tagline ? (
                <p className="mt-2 text-lg italic text-muted-foreground">{series.tagline}</p>
              ) : null}

              <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1 font-semibold text-gold">
                  <Star className="h-4 w-4 fill-current" aria-hidden />
                  {series.voteAverage.toFixed(1)}
                  <span className="font-normal text-muted-foreground">
                    ({series.voteCount.toLocaleString()})
                  </span>
                </span>
                <span>{releaseYear(series.firstAirDate)}</span>
                <span className="inline-flex items-center gap-1">
                  <Layers className="h-4 w-4" aria-hidden />
                  {series.numberOfSeasons} season{series.numberOfSeasons === 1 ? "" : "s"} ·{" "}
                  {series.numberOfEpisodes} episodes
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-4 w-4" aria-hidden />
                  {formatEpisodeRuntime(series.episodeRuntime)}
                </span>
                {series.omdb?.rated ? <span>Rated {series.omdb.rated}</span> : null}
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                {series.genres.map((genre) => (
                  <Badge key={genre.id} variant="secondary">
                    {genre.name}
                  </Badge>
                ))}
              </div>

              <p className="mt-6 max-w-3xl text-base leading-relaxed text-muted-foreground">
                {series.overview || "No synopsis available yet."}
              </p>

              {series.trailer ? (
                <button
                  onClick={() => setTrailerOpen(true)}
                  className="mt-8 inline-flex h-11 items-center gap-2 rounded-full bg-gradient-primary px-7 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.03]"
                >
                  <Play className="h-4 w-4 fill-current" aria-hidden /> Watch trailer
                </button>
              ) : null}

              <dl className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
                <Stat label="Status" value={series.status ?? "—"} />
                <Stat label="Type" value={series.type ?? "Scripted"} />
                <Stat label="Last aired" value={series.lastAirDate ?? "—"} />
                <Stat
                  label="Language"
                  value={series.spokenLanguages[0] ?? series.originalLanguage.toUpperCase()}
                />
              </dl>

              {series.omdb?.imdbRating ? (
                <p className="mt-6 text-sm text-muted-foreground">
                  <span className="font-semibold text-gold">IMDb {series.omdb.imdbRating}/10</span>
                  {series.omdb.imdbVotes ? ` · ${series.omdb.imdbVotes} votes` : ""}
                </p>
              ) : null}

              {series.networks.length ? (
                <ul className="mt-6 flex flex-wrap items-center gap-3" aria-label="Networks">
                  {series.networks.map((network) => (
                    <li
                      key={network.id}
                      className="glass-panel flex items-center gap-2 rounded-full py-1.5 pl-3 pr-4 text-sm"
                    >
                      {network.logoPath ? (
                        <img
                          src={`${TMDB_IMAGE_BASE}/w92${network.logoPath}`}
                          alt=""
                          loading="lazy"
                          className="h-5 w-auto max-w-14 object-contain"
                        />
                      ) : (
                        <Tv className="h-4 w-4" aria-hidden />
                      )}
                      {network.name}
                    </li>
                  ))}
                </ul>
              ) : null}

              {series.keywords.length ? (
                <ul className="mt-6 flex flex-wrap gap-2" aria-label="Themes">
                  {series.keywords.map((keyword) => (
                    <li
                      key={keyword}
                      className="rounded-full bg-surface px-3 py-1 text-xs text-muted-foreground"
                    >
                      {keyword}
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          </div>
        </div>
      </div>

      <Dialog open={trailerOpen} onOpenChange={setTrailerOpen}>
        <DialogContent className="max-w-4xl border-border bg-card p-0">
          <DialogHeader className="px-6 pt-6">
            <DialogTitle className="font-display text-2xl uppercase">{series.title}</DialogTitle>
          </DialogHeader>
          <div className="aspect-video w-full overflow-hidden rounded-b-lg bg-surface">
            {series.trailer ? (
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${series.trailer.key}?autoplay=1&rel=0`}
                title={`${series.title} trailer`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="h-full w-full border-0"
              />
            ) : null}
          </div>
        </DialogContent>
      </Dialog>

      <div className="mx-auto max-w-7xl space-y-14 px-4 sm:px-6 lg:px-8">
        {series.seasons.length ? (
          <section>
            <h2 className="mb-4 font-display text-2xl uppercase tracking-wide sm:text-3xl">
              Seasons
            </h2>
            <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {series.seasons.map((season) => (
                <li key={season.id}>
                  <Link
                    to="/series/$seriesId/season/$seasonNumber"
                    params={{
                      seriesId: String(series.id),
                      seasonNumber: String(season.seasonNumber),
                    }}
                    className="glass-panel grid h-full grid-cols-[72px_minmax(0,1fr)] gap-4 rounded-2xl p-4 transition-colors hover:border-primary/50"
                  >
                  {posterUrl(season.posterPath, "w185") ? (
                    <img
                      src={posterUrl(season.posterPath, "w185")!}
                      alt=""
                      loading="lazy"
                      className="aspect-[2/3] w-full rounded-lg object-cover"
                    />
                  ) : (
                    <div className="aspect-[2/3] w-full rounded-lg bg-surface" />
                  )}
                  <div className="min-w-0">
                    <p className="truncate font-semibold">{season.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {season.episodeCount} episodes · {releaseYear(season.airDate)}
                    </p>
                    <p className="mt-2 line-clamp-3 text-xs text-muted-foreground">
                      {season.overview || "No season synopsis available yet."}
                    </p>
                    <p className="mt-2 text-xs font-semibold text-primary">View episodes →</p>
                  </div>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        ) : null}

        {series.cast.length ? (
          <section>
            <h2 className="mb-4 font-display text-2xl uppercase tracking-wide sm:text-3xl">
              Top billed cast
            </h2>
            <div className="flex gap-4 overflow-x-auto pb-4">
              {series.cast.map((member) => (
                <figure key={`${member.id}-${member.character}`} className="w-32 shrink-0">
                  <Link
                    to="/person/$personId"
                    params={{ personId: String(member.id) }}
                    className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                  >
                    {profileUrl(member.profilePath) ? (
                      <img
                        src={profileUrl(member.profilePath)!}
                        alt={member.name}
                        loading="lazy"
                        width={185}
                        height={278}
                        className="aspect-[2/3] w-full rounded-xl object-cover transition-transform duration-200 hover:scale-105"
                      />
                    ) : (
                      <div className="aspect-[2/3] w-full rounded-xl bg-surface" />
                    )}
                    <figcaption className="mt-2">
                      <span className="block truncate text-sm font-medium">{member.name}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {member.character}
                      </span>
                    </figcaption>
                  </Link>
                </figure>
              ))}
            </div>
          </section>
        ) : null}

        <section aria-labelledby="airdates-heading">
          <h2
            id="airdates-heading"
            className="mb-4 flex items-center gap-2 font-display text-2xl uppercase tracking-wide sm:text-3xl"
          >
            <CalendarDays className="h-5 w-5 text-primary" aria-hidden />
            Air dates
          </h2>
          <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="First aired" value={series.firstAirDate ?? "—"} />
            <Stat label="Latest episode" value={series.lastAirDate ?? "—"} />
            <Stat label="Status" value={series.status ?? "—"} />
            <Stat
              label="Next release"
              value={series.inProduction ? "In production" : "Completed"}
            />
          </dl>
          {series.seasons.length ? (
            <ul className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {series.seasons.map((season) => (
                <li
                  key={season.id}
                  className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card/60 px-4 py-3 text-sm"
                >
                  <span className="truncate">{season.name}</span>
                  <span className="shrink-0 text-muted-foreground">
                    {season.airDate ? formatReleaseDate(season.airDate) : "TBA"}
                  </span>
                </li>
              ))}
            </ul>
          ) : null}
        </section>

        <AwardsPanel awards={series.omdb?.awards} title={series.title} />

        {series.providers ? <StreamingPanel providers={series.providers} /> : null}

        {series.images.length ? (
          <section>
            <h2 className="mb-4 font-display text-2xl uppercase tracking-wide sm:text-3xl">
              Gallery
            </h2>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {series.images.map((path) => (
                <img
                  key={path}
                  src={backdropUrl(path, "w780") ?? ""}
                  alt={`Still from ${series.title}`}
                  loading="lazy"
                  className="aspect-video w-full rounded-xl border border-border object-cover"
                />
              ))}
            </div>
          </section>
        ) : null}

        <MovieRow
          title="More series like this"
          movies={series.recommendations.length ? series.recommendations : series.similar}
          mediaType="tv"
        />
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-card/60 p-4">
      <dt className="text-xs uppercase tracking-wider text-muted-foreground">{label}</dt>
      <dd className="mt-1 truncate text-sm font-semibold">{value}</dd>
    </div>
  );
}
