import { createFileRoute, Link } from "@tanstack/react-router";

import { HeroBanner } from "@/components/movie/HeroBanner";
import { MovieRow } from "@/components/movie/MovieRow";
import { SetupNotice } from "@/components/common/SetupNotice";
import { Button } from "@/components/ui/button";
import { getHome } from "@/lib/tmdb.functions";
import { Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CineVerse AI — Discover Your Next Favourite Film" },
      {
        name: "description",
        content:
          "Trending, top rated and upcoming films in one cinematic hub. Watch trailers, build watchlists, read reviews and get AI-curated picks.",
      },
      { property: "og:title", content: "CineVerse AI — Discover Your Next Favourite Film" },
      {
        property: "og:description",
        content:
          "Trending, top rated and upcoming films in one cinematic hub. Watch trailers, build watchlists, read reviews and get AI-curated picks.",
      },
    ],
  }),
  loader: () => getHome(),
  component: HomePage,
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-3xl px-4 py-32">
      <p className="text-center text-sm text-muted-foreground">{error.message}</p>
    </div>
  ),
});

function HomePage() {
  const result = Route.useLoaderData();

  if (!result.ok) {
    return (
      <div className="px-4 py-32">
        <SetupNotice result={result} />
      </div>
    );
  }

  const home = result.data;

  return (
    <div className="pb-20">
      <HeroBanner movies={home.hero} />

      <div className="mx-auto max-w-7xl space-y-14 px-4 pt-14 sm:px-6 lg:px-8">
        <MovieRow
          title="Trending this week"
          subtitle="What the world is watching right now"
          movies={home.trending}
          viewAllTo="/trending"
        />

        <section className="relative overflow-hidden rounded-3xl border border-border bg-card p-8 shadow-cinema sm:p-12">
          <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-gradient-primary opacity-20 blur-3xl" />
          <div className="relative grid gap-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
                CineVerse AI
              </p>
              <h2 className="mt-2 font-display text-3xl uppercase sm:text-4xl">
                Describe a mood. Get the perfect film.
              </h2>
              <p className="mt-3 max-w-xl text-sm text-muted-foreground">
                Our curator model reads your taste — not just genre tags — and returns a short,
                hand-picked shortlist with a reason for every choice.
              </p>
            </div>
            <Button variant="hero" size="lg" asChild className="shrink-0">
              <Link to="/recommendations">
                <Sparkles aria-hidden />
                Get recommendations
              </Link>
            </Button>
          </div>
        </section>

        <MovieRow title="In theatres now" movies={home.nowPlaying} viewAllTo="/trending" />
        <MovieRow title="Popular on CineVerse" movies={home.popular} viewAllTo="/genres" />
        <MovieRow title="Highest rated of all time" movies={home.topRated} viewAllTo="/top-rated" />
        <MovieRow title="Coming soon" movies={home.upcoming} viewAllTo="/upcoming" />
      </div>
    </div>
  );
}
