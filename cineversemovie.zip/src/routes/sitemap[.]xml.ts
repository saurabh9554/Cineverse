import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

import { INDUSTRIES } from "@/lib/industries";

const BASE_URL = "https://cineversemovie.lovable.app";

interface SitemapEntry {
  path: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries: SitemapEntry[] = [
          { path: "/", changefreq: "daily", priority: "1.0" },
          { path: "/trending", changefreq: "daily", priority: "0.9" },
          { path: "/upcoming", changefreq: "daily", priority: "0.8" },
          { path: "/top-rated", changefreq: "weekly", priority: "0.8" },
          { path: "/genres", changefreq: "weekly", priority: "0.7" },
          { path: "/search", changefreq: "weekly", priority: "0.6" },
          { path: "/series", changefreq: "daily", priority: "0.9" },
          { path: "/tv-shows", changefreq: "daily", priority: "0.8" },
          { path: "/news", changefreq: "daily", priority: "0.8" },
          { path: "/recommendations", changefreq: "monthly", priority: "0.6" },
          { path: "/auth", changefreq: "yearly", priority: "0.3" },
          ...INDUSTRIES.map((industry) => ({
            path: `/cinema/${industry.slug}`,
            changefreq: "weekly" as const,
            priority: "0.7",
          })),
        ];

        const urls = entries.map((e) =>
          [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`,
          ]
            .filter(Boolean)
            .join("\n"),
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
