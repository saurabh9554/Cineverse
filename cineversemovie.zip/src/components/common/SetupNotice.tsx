import { KeyRound } from "lucide-react";

import type { DataResult } from "@/lib/data-result";

/** Shown when the movie data service (or AI) has not been configured yet. */
export function SetupNotice({ result }: { result: Extract<DataResult<unknown>, { ok: false }> }) {
  const isConfig = result.reason === "not_configured";

  return (
    <div className="mx-auto max-w-2xl rounded-2xl border border-border bg-card p-8 text-center shadow-cinema">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-xl bg-gradient-primary">
        <KeyRound className="h-6 w-6 text-primary-foreground" aria-hidden />
      </span>
      <h2 className="mt-5 font-display text-2xl uppercase">
        {isConfig ? "Connect the film catalogue" : "Something went wrong"}
      </h2>
      <p className="mt-3 text-sm text-muted-foreground">
        {isConfig
          ? "CineVerse needs a TMDB API key to load films. Add a secret named TMDB_API_KEY in Project Settings → Secrets (and optionally OMDB_API_KEY for IMDb ratings, awards and box-office data)."
          : result.message}
      </p>
      {isConfig ? (
        <p className="mt-4 text-xs text-muted-foreground">
          A free key takes about a minute at themoviedb.org → Settings → API.
        </p>
      ) : null}
    </div>
  );
}
