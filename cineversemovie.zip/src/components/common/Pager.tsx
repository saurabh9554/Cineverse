import { ChevronLeft, ChevronRight } from "lucide-react";

import { Button } from "@/components/ui/button";

export function Pager({
  page,
  totalPages,
  onPageChange,
}: {
  page: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}) {
  if (totalPages <= 1) return null;

  return (
    <nav className="flex items-center justify-center gap-3 pt-4" aria-label="Pagination">
      <Button
        variant="glass"
        size="sm"
        disabled={page <= 1}
        onClick={() => onPageChange(page - 1)}
      >
        <ChevronLeft aria-hidden /> Previous
      </Button>
      <span className="text-sm text-muted-foreground">
        Page <strong className="text-foreground">{page}</strong> of {totalPages}
      </span>
      <Button
        variant="glass"
        size="sm"
        disabled={page >= totalPages}
        onClick={() => onPageChange(page + 1)}
      >
        Next <ChevronRight aria-hidden />
      </Button>
    </nav>
  );
}
