import { CalendarDays } from "lucide-react";

import {
  RELEASE_TYPE_LABELS,
  formatReleaseDate,
  type RegionalRelease,
} from "@/lib/tmdb.types";

/**
 * Regional release calendar sourced from TMDB's licensed release_dates data.
 * India is always surfaced first, followed by other major markets.
 */
export function ReleaseDatesPanel({ releases }: { releases: RegionalRelease[] }) {
  if (!releases.length) return null;

  return (
    <section aria-labelledby="release-dates-heading">
      <h2
        id="release-dates-heading"
        className="mb-4 flex items-center gap-2 font-display text-2xl uppercase tracking-wide sm:text-3xl"
      >
        <CalendarDays className="h-5 w-5 text-primary" aria-hidden />
        Release dates
      </h2>
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {releases.map((region) => (
          <li key={region.country} className="glass-panel rounded-2xl p-4">
            <p className="flex items-center justify-between text-sm font-semibold">
              <span>{region.countryName}</span>
              <span className="text-xs uppercase tracking-wider text-muted-foreground">
                {region.country}
              </span>
            </p>
            <ul className="mt-3 space-y-2">
              {region.entries.map((entry, index) => (
                <li
                  key={`${entry.type}-${entry.date}-${index}`}
                  className="flex items-start justify-between gap-3 text-sm"
                >
                  <span className="text-muted-foreground">
                    {RELEASE_TYPE_LABELS[entry.type] ?? "Release"}
                    {entry.certification ? (
                      <span className="ml-2 rounded bg-surface px-1.5 py-0.5 text-xs text-foreground">
                        {entry.certification}
                      </span>
                    ) : null}
                    {entry.note ? (
                      <span className="block text-xs opacity-80">{entry.note}</span>
                    ) : null}
                  </span>
                  <span className="shrink-0 font-medium">{formatReleaseDate(entry.date)}</span>
                </li>
              ))}
            </ul>
          </li>
        ))}
      </ul>
    </section>
  );
}
