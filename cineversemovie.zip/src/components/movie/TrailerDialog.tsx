import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { getMovieDetail } from "@/lib/tmdb.functions";

/** Lazily loads a film's YouTube trailer only when opened. */
export function TrailerDialog({
  movieId,
  onOpenChange,
}: {
  movieId: number | null;
  onOpenChange: (open: boolean) => void;
}) {
  const fetchMovie = useServerFn(getMovieDetail);

  const { data, isLoading } = useQuery({
    queryKey: ["movie", movieId],
    queryFn: () => fetchMovie({ data: { id: movieId as number } }),
    enabled: movieId != null,
    staleTime: 5 * 60_000,
  });

  const detail = data?.ok ? data.data : null;
  const trailer = detail?.trailer ?? null;

  return (
    <Dialog open={movieId != null} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl border-border bg-card p-0">
        <DialogHeader className="px-6 pt-6">
          <DialogTitle className="font-display text-2xl uppercase">
            {detail?.title ?? "Trailer"}
          </DialogTitle>
        </DialogHeader>

        <div className="aspect-video w-full overflow-hidden rounded-b-lg bg-surface">
          {isLoading ? (
            <div className="h-full w-full shimmer" />
          ) : trailer ? (
            <iframe
              key={trailer.key}
              src={`https://www.youtube-nocookie.com/embed/${trailer.key}?autoplay=1&rel=0`}
              title={`${detail?.title ?? "Movie"} trailer`}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="h-full w-full border-0"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
              No trailer is available for this title yet.
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
