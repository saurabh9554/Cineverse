import { SlidersHorizontal, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SORT_OPTIONS, type Genre } from "@/lib/tmdb.types";
import { cn } from "@/lib/utils";

export type FilterValues = {
  genres: number[];
  yearFrom: number;
  yearTo: number;
  minRating: number;
  sortBy: string;
};

const CURRENT_YEAR = new Date().getFullYear() + 2;

export function FilterBar({
  genres,
  value,
  onChange,
  onReset,
}: {
  genres: Genre[];
  value: FilterValues;
  onChange: (next: Partial<FilterValues>) => void;
  onReset: () => void;
}) {
  function toggleGenre(id: number) {
    const next = value.genres.includes(id)
      ? value.genres.filter((g) => g !== id)
      : [...value.genres, id];
    onChange({ genres: next });
  }

  return (
    <div className="space-y-5 rounded-2xl border border-border bg-card p-5">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <h2 className="inline-flex min-w-0 items-center gap-2 text-sm font-semibold uppercase tracking-wider">
          <SlidersHorizontal className="h-4 w-4 shrink-0 text-primary" aria-hidden />
          <span className="truncate">Refine results</span>
        </h2>
        <Button variant="ghost" size="sm" onClick={onReset} className="shrink-0">
          <X aria-hidden /> Reset
        </Button>
      </div>

      <div>
        <p className="mb-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
          Genres
        </p>
        <div className="flex flex-wrap gap-2">
          {genres.map((genre) => (
            <button
              key={genre.id}
              type="button"
              aria-pressed={value.genres.includes(genre.id)}
              onClick={() => toggleGenre(genre.id)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                value.genres.includes(genre.id)
                  ? "border-primary bg-primary/15 text-primary"
                  : "border-border text-muted-foreground hover:border-muted-foreground hover:text-foreground",
              )}
            >
              {genre.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div>
          <label
            className="mb-3 block text-xs font-medium uppercase tracking-wider text-muted-foreground"
            htmlFor="year-range"
          >
            Release years · {value.yearFrom}–{value.yearTo}
          </label>
          <Slider
            id="year-range"
            min={1950}
            max={CURRENT_YEAR}
            step={1}
            value={[value.yearFrom, value.yearTo]}
            onValueChange={([from, to]) => onChange({ yearFrom: from, yearTo: to })}
          />
        </div>

        <div>
          <label
            className="mb-3 block text-xs font-medium uppercase tracking-wider text-muted-foreground"
            htmlFor="min-rating"
          >
            Minimum rating · {value.minRating.toFixed(1)}
          </label>
          <Slider
            id="min-rating"
            min={0}
            max={9}
            step={0.5}
            value={[value.minRating]}
            onValueChange={([rating]) => onChange({ minRating: rating })}
          />
        </div>

        <div>
          <p className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Sort by
          </p>
          <Select value={value.sortBy} onValueChange={(sortBy) => onChange({ sortBy })}>
            <SelectTrigger className="bg-surface" aria-label="Sort results">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SORT_OPTIONS.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
