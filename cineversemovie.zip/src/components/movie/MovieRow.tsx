import { Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";

import { MovieCard } from "./MovieCard";
import type { MovieSummary } from "@/lib/tmdb.types";

type MovieRowProps = {
  title: string;
  subtitle?: string;
  movies: MovieSummary[];
  viewAllTo?: string;
  mediaType?: "movie" | "tv";
};

export function MovieRow({ title, subtitle, movies, viewAllTo, mediaType = "movie" }: MovieRowProps) {
  if (!movies.length) return null;

  return (
    <section className="space-y-4">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4">
        <div className="min-w-0">
          <h2 className="truncate font-display text-2xl uppercase tracking-wide sm:text-3xl">
            {title}
          </h2>
          {subtitle ? (
            <p className="mt-1 truncate text-sm text-muted-foreground">{subtitle}</p>
          ) : null}
        </div>
        {viewAllTo ? (
          <Link
            to={viewAllTo}
            className="inline-flex shrink-0 items-center gap-1 text-sm font-medium text-primary transition-colors hover:text-primary-glow"
          >
            View all
            <ChevronRight className="h-4 w-4" aria-hidden />
          </Link>
        ) : null}
      </header>

      <div className="no-scrollbar -mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-2">
        {movies.map((movie) => (
          <div key={movie.id} className="w-36 shrink-0 snap-start sm:w-44 lg:w-48">
            <MovieCard movie={movie} mediaType={mediaType} />
          </div>
        ))}
      </div>
    </section>
  );
}
