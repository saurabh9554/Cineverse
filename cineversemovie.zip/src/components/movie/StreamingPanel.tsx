import { ExternalLink } from "lucide-react";

import { TMDB_IMAGE_BASE, type WatchProvider, type WatchProviders } from "@/lib/tmdb.types";

const GROUPS: { key: keyof Pick<WatchProviders, "flatrate" | "rent" | "buy">; label: string }[] = [
  { key: "flatrate", label: "Stream" },
  { key: "rent", label: "Rent" },
  { key: "buy", label: "Buy" },
];

function ProviderChip({ provider }: { provider: WatchProvider }) {
  return (
    <li className="glass-panel flex items-center gap-2 rounded-full py-1.5 pl-1.5 pr-4">
      {provider.logoPath ? (
        <img
          src={`${TMDB_IMAGE_BASE}/w92${provider.logoPath}`}
          alt=""
          loading="lazy"
          width={28}
          height={28}
          className="h-7 w-7 rounded-full object-cover"
        />
      ) : (
        <span className="h-7 w-7 rounded-full bg-surface" />
      )}
      <span className="text-sm font-medium">{provider.name}</span>
    </li>
  );
}

/** Streaming availability, sourced from JustWatch via the TMDB API. */
export function StreamingPanel({ providers }: { providers: WatchProviders }) {
  const regionName =
    typeof Intl.DisplayNames === "function"
      ? new Intl.DisplayNames(["en"], { type: "region" }).of(providers.region)
      : providers.region;

  return (
    <section aria-label="Where to watch" className="space-y-4">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4">
        <h2 className="truncate font-display text-2xl uppercase tracking-wide sm:text-3xl">
          Where to watch
        </h2>
        {providers.link ? (
          <a
            href={providers.link}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex shrink-0 items-center gap-1 text-sm font-medium text-primary hover:text-primary-glow"
          >
            All options <ExternalLink className="h-3.5 w-3.5" aria-hidden />
          </a>
        ) : null}
      </div>
      <p className="text-xs text-muted-foreground">
        Availability for {regionName}. Provided by JustWatch through the TMDB API.
      </p>

      <div className="space-y-4">
        {GROUPS.map(({ key, label }) =>
          providers[key].length ? (
            <div key={key}>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                {label}
              </h3>
              <ul className="flex flex-wrap gap-2">
                {providers[key].map((provider) => (
                  <ProviderChip key={`${key}-${provider.id}`} provider={provider} />
                ))}
              </ul>
            </div>
          ) : null,
        )}
      </div>
    </section>
  );
}
