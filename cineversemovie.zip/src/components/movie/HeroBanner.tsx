import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Info, Play, Star } from "lucide-react";

import { Button } from "@/components/ui/button";
import { TrailerDialog } from "./TrailerDialog";
import { backdropUrl, releaseYear, type MovieSummary } from "@/lib/tmdb.types";

export function HeroBanner({ movies }: { movies: MovieSummary[] }) {
  const [index, setIndex] = useState(0);
  const [trailerFor, setTrailerFor] = useState<number | null>(null);

  if (!movies.length) return null;
  const movie = movies[Math.min(index, movies.length - 1)];
  const backdrop = backdropUrl(movie.backdropPath, "original");

  return (
    <section className="relative isolate min-h-[78vh] w-full overflow-hidden">
      {backdrop ? (
        <img
          src={backdrop}
          alt=""
          aria-hidden
          className="absolute inset-0 h-full w-full object-cover object-top"
        />
      ) : null}
      <div className="absolute inset-0 bg-fade-bottom" />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />

      <div className="relative mx-auto flex min-h-[78vh] w-full max-w-7xl flex-col justify-end gap-6 px-4 pb-16 pt-32 sm:px-6 lg:px-8">
        <div className="max-w-2xl space-y-5">
          <span className="inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-primary">
            Trending now
          </span>

          <h1 className="font-display text-5xl uppercase leading-[0.95] sm:text-6xl lg:text-7xl">
            {movie.title}
          </h1>

          <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1 font-semibold text-gold">
              <Star className="h-4 w-4 fill-current" aria-hidden />
              {movie.voteAverage.toFixed(1)}
            </span>
            <span aria-hidden>•</span>
            <span>{releaseYear(movie.releaseDate)}</span>
            <span aria-hidden>•</span>
            <span>{movie.voteCount.toLocaleString()} ratings</span>
          </div>

          <p className="line-clamp-3 max-w-xl text-base text-foreground/80">{movie.overview}</p>

          <div className="flex flex-wrap gap-3">
            <Button variant="hero" size="lg" onClick={() => setTrailerFor(movie.id)}>
              <Play className="fill-current" aria-hidden />
              Watch trailer
            </Button>
            <Button variant="glass" size="lg" asChild>
              <Link to="/movie/$movieId" params={{ movieId: String(movie.id) }}>
                <Info aria-hidden />
                More info
              </Link>
            </Button>
          </div>
        </div>

        <div className="flex gap-2" role="tablist" aria-label="Featured films">
          {movies.map((item, i) => (
            <button
              key={item.id}
              role="tab"
              aria-selected={i === index}
              aria-label={item.title}
              onClick={() => setIndex(i)}
              className={
                i === index
                  ? "h-1.5 w-10 rounded-full bg-primary transition-all"
                  : "h-1.5 w-5 rounded-full bg-muted transition-all hover:bg-muted-foreground"
              }
            />
          ))}
        </div>
      </div>

      <TrailerDialog
        movieId={trailerFor}
        onOpenChange={(open) => !open && setTrailerFor(null)}
      />
    </section>
  );
}
