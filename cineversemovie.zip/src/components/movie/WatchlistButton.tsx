import { useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bookmark, BookmarkCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { getWatchlistIds, toggleWatchlist } from "@/lib/user.functions";
import type { MovieSummary } from "@/lib/tmdb.types";

export function WatchlistButton({
  movie,
  size = "default",
}: {
  movie: Pick<MovieSummary, "id" | "title" | "posterPath" | "releaseDate" | "voteAverage">;
  size?: "default" | "sm" | "lg";
}) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const idsFn = useServerFn(getWatchlistIds);
  const toggleFn = useServerFn(toggleWatchlist);

  const { data: ids } = useQuery({
    queryKey: ["watchlist-ids"],
    queryFn: () => idsFn(),
    enabled: Boolean(user),
    staleTime: 30_000,
  });

  const saved = (ids ?? []).includes(movie.id);

  const mutation = useMutation({
    mutationFn: () =>
      toggleFn({
        data: {
          movieId: movie.id,
          title: movie.title,
          posterPath: movie.posterPath,
          releaseDate: movie.releaseDate,
          voteAverage: movie.voteAverage,
        },
      }),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["watchlist-ids"] });
      queryClient.invalidateQueries({ queryKey: ["watchlist"] });
      toast.success(result.inWatchlist ? "Added to your watchlist" : "Removed from your watchlist");
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "Could not update watchlist"),
  });

  if (!user) {
    return (
      <Button variant="glass" size={size} onClick={() => navigate({ to: "/auth" })}>
        <Bookmark aria-hidden />
        Sign in to save
      </Button>
    );
  }

  return (
    <Button
      variant={saved ? "gold" : "glass"}
      size={size}
      disabled={mutation.isPending}
      onClick={() => mutation.mutate()}
    >
      {mutation.isPending ? (
        <Loader2 className="animate-spin" aria-hidden />
      ) : saved ? (
        <BookmarkCheck aria-hidden />
      ) : (
        <Bookmark aria-hidden />
      )}
      {saved ? "In watchlist" : "Add to watchlist"}
    </Button>
  );
}
