import { Link } from "@tanstack/react-router";
import { Star } from "lucide-react";

import { cn } from "@/lib/utils";
import { posterUrl, releaseYear, type MovieSummary } from "@/lib/tmdb.types";

type MovieCardProps = {
  movie: MovieSummary;
  className?: string;
  priority?: boolean;
  /** Switches the destination route between films and web series. */
  mediaType?: "movie" | "tv";
};

export function MovieCard({ movie, className, priority = false, mediaType = "movie" }: MovieCardProps) {
  const poster = posterUrl(movie.posterPath, "w342");
  const linkProps =
    mediaType === "tv"
      ? ({ to: "/series/$seriesId", params: { seriesId: String(movie.id) } } as const)
      : ({ to: "/movie/$movieId", params: { movieId: String(movie.id) } } as const);

  return (
    <Link
      {...linkProps}
      className={cn("group block poster-hover rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className)}
      aria-label={`${movie.title} (${releaseYear(movie.releaseDate)})`}
    >
      <div className="relative aspect-2/3 overflow-hidden rounded-xl bg-surface">
        {poster ? (
          <img
            src={poster}
            alt={`${movie.title} poster`}
            loading={priority ? "eager" : "lazy"}
            decoding="async"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center px-3 text-center text-xs text-muted-foreground">
            No artwork available
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/10 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

        <span className="absolute left-2 top-2 inline-flex items-center gap-1 rounded-full bg-background/80 px-2 py-1 text-[11px] font-semibold text-gold backdrop-blur-sm">
          <Star className="h-3 w-3 fill-current" aria-hidden />
          {movie.voteAverage ? movie.voteAverage.toFixed(1) : "NR"}
        </span>

        <p className="absolute inset-x-0 bottom-0 line-clamp-3 p-3 text-xs text-foreground/85 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          {movie.overview || "No synopsis available yet."}
        </p>
      </div>

      <div className="mt-2 min-w-0 px-0.5">
        <h3 className="truncate text-sm font-semibold text-foreground">{movie.title}</h3>
        <p className="text-xs text-muted-foreground">{releaseYear(movie.releaseDate)}</p>
      </div>
    </Link>
  );
}

export function MovieCardSkeleton() {
  return (
    <div className="space-y-2">
      <div className="aspect-2/3 rounded-xl shimmer" />
      <div className="h-3 w-3/4 rounded shimmer" />
      <div className="h-3 w-1/3 rounded shimmer" />
    </div>
  );
}
