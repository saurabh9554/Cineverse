import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { deleteMyReview, getMovieReviews, upsertReview } from "@/lib/user.functions";
import { cn } from "@/lib/utils";

export function ReviewSection({ movieId, movieTitle }: { movieId: number; movieTitle: string }) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const listFn = useServerFn(getMovieReviews);
  const saveFn = useServerFn(upsertReview);
  const deleteFn = useServerFn(deleteMyReview);

  const [rating, setRating] = useState(8);
  const [content, setContent] = useState("");

  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ["reviews", movieId],
    queryFn: () => listFn({ data: { movieId } }),
  });

  const save = useMutation({
    mutationFn: () => saveFn({ data: { movieId, movieTitle, rating, content } }),
    onSuccess: () => {
      setContent("");
      queryClient.invalidateQueries({ queryKey: ["reviews", movieId] });
      toast.success("Your review is live");
    },
    onError: (error) => toast.error(error instanceof Error ? error.message : "Could not save review"),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reviews", movieId] });
      toast.success("Review deleted");
    },
  });

  const average = reviews.length
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : null;

  return (
    <section className="space-y-6" aria-labelledby="reviews-heading">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <h2 id="reviews-heading" className="truncate font-display text-2xl uppercase sm:text-3xl">
          Member reviews
        </h2>
        {average ? (
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-secondary px-3 py-1 text-sm font-semibold text-gold">
            <Star className="h-4 w-4 fill-current" aria-hidden />
            {average} · {reviews.length}
          </span>
        ) : null}
      </div>

      {user ? (
        <form
          className="space-y-4 rounded-2xl border border-border bg-card p-5"
          onSubmit={(e) => {
            e.preventDefault();
            save.mutate();
          }}
        >
          <fieldset>
            <legend className="mb-2 text-sm font-medium text-muted-foreground">Your rating</legend>
            <div className="flex flex-wrap gap-1.5">
              {Array.from({ length: 10 }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  aria-label={`Rate ${i + 1} out of 10`}
                  aria-pressed={rating === i + 1}
                  onClick={() => setRating(i + 1)}
                  className={cn(
                    "grid h-9 w-9 place-items-center rounded-lg border text-sm font-semibold transition-colors",
                    rating >= i + 1
                      ? "border-gold bg-gold/15 text-gold"
                      : "border-border text-muted-foreground hover:border-muted-foreground",
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </fieldset>

          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`What did you think of ${movieTitle}?`}
            aria-label="Your review"
            maxLength={4000}
            className="min-h-28 bg-surface"
          />

          <Button type="submit" variant="hero" disabled={save.isPending}>
            {save.isPending ? <Loader2 className="animate-spin" aria-hidden /> : null}
            Publish review
          </Button>
        </form>
      ) : (
        <div className="rounded-2xl border border-dashed border-border p-6 text-sm text-muted-foreground">
          <Link to="/auth" className="font-medium text-primary hover:underline">
            Sign in
          </Link>{" "}
          to rate and review this film.
        </div>
      )}

      {isLoading ? (
        <div className="h-24 rounded-2xl shimmer" />
      ) : reviews.length ? (
        <ul className="space-y-4">
          {reviews.map((review) => (
            <li key={review.id} className="rounded-2xl border border-border bg-card p-5">
              <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3">
                <Avatar className="h-9 w-9 shrink-0">
                  <AvatarImage src={review.avatarUrl ?? undefined} alt="" />
                  <AvatarFallback className="bg-secondary text-xs">
                    {review.author.slice(0, 1).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{review.author}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(review.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <span className="inline-flex shrink-0 items-center gap-1 text-sm font-semibold text-gold">
                  <Star className="h-4 w-4 fill-current" aria-hidden />
                  {review.rating}/10
                </span>
              </div>
              {review.content ? (
                <p className="mt-3 whitespace-pre-line text-sm text-foreground/85">{review.content}</p>
              ) : null}
              {user?.id === review.userId ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-3 text-destructive"
                  onClick={() => remove.mutate(review.id)}
                >
                  <Trash2 aria-hidden /> Delete
                </Button>
              ) : null}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-muted-foreground">No reviews yet — be the first.</p>
      )}
    </section>
  );
}
