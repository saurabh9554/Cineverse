import { Award, Trophy } from "lucide-react";

import { parseAwards } from "@/lib/tmdb.types";

/**
 * Awards recognition for a film, series or TV show. Sourced from OMDb's
 * licensed awards summary — nothing is estimated or invented.
 */
export function AwardsPanel({
  awards,
  title,
}: {
  awards: string | null | undefined;
  title?: string;
}) {
  const summary = parseAwards(awards);
  if (!summary) return null;

  const stats = [
    { label: "Oscar wins", value: summary.oscarWins },
    { label: "Oscar nominations", value: summary.oscarNominations },
    { label: "Total wins", value: summary.wins },
    { label: "Total nominations", value: summary.nominations },
  ].filter((stat) => stat.value > 0);

  return (
    <section aria-labelledby="awards-heading">
      <h2
        id="awards-heading"
        className="mb-4 flex items-center gap-2 font-display text-2xl uppercase tracking-wide sm:text-3xl"
      >
        <Trophy className="h-5 w-5 text-gold" aria-hidden />
        Awards &amp; recognition
      </h2>

      <div className="glass-panel rounded-2xl border border-gold/25 p-5">
        {stats.length ? (
          <dl className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {stats.map((stat) => (
              <div key={stat.label}>
                <dt className="text-xs uppercase tracking-wider text-muted-foreground">
                  {stat.label}
                </dt>
                <dd className="mt-1 text-2xl font-semibold text-gold">{stat.value}</dd>
              </div>
            ))}
          </dl>
        ) : null}

        <ul className={stats.length ? "mt-5 space-y-2" : "space-y-2"}>
          {summary.highlights.map((line) => (
            <li key={line} className="flex items-start gap-2 text-sm text-muted-foreground">
              <Award className="mt-0.5 h-4 w-4 shrink-0 text-gold" aria-hidden />
              <span>{line}</span>
            </li>
          ))}
        </ul>

        <p className="mt-4 text-xs text-muted-foreground">
          Awards data for {title ?? "this title"} provided by OMDb.
        </p>
      </div>
    </section>
  );
}
