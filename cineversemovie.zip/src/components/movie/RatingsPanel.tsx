import { Star } from "lucide-react";

import type { MovieDetail } from "@/lib/tmdb.types";

type Score = { label: string; value: string; note?: string };

/**
 * Shows only ratings returned by licensed APIs (TMDB + OMDb), which is where
 * the IMDb, Rotten Tomatoes and Metacritic values come from. Missing sources
 * are omitted rather than estimated.
 */
export function RatingsPanel({ movie }: { movie: MovieDetail }) {
  const scores: Score[] = [];

  if (movie.voteCount) {
    scores.push({
      label: "TMDB",
      value: `${movie.voteAverage.toFixed(1)}/10`,
      note: `${movie.voteCount.toLocaleString()} votes`,
    });
  }
  if (movie.omdb?.imdbRating) {
    scores.push({
      label: "IMDb",
      value: `${movie.omdb.imdbRating}/10`,
      note: movie.omdb.imdbVotes ? `${movie.omdb.imdbVotes} votes` : undefined,
    });
  }
  const rt = movie.omdb?.ratings.find((r) => r.source === "Rotten Tomatoes");
  if (rt) scores.push({ label: "Rotten Tomatoes", value: rt.value, note: "Tomatometer" });
  if (movie.omdb?.metascore) {
    scores.push({ label: "Metacritic", value: `${movie.omdb.metascore}/100`, note: "Metascore" });
  }

  if (!scores.length) return null;

  return (
    <section aria-label="Critic and audience ratings" className="mt-8">
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {scores.map((score) => (
          <li key={score.label} className="glass-panel rounded-2xl p-4">
            <p className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-muted-foreground">
              <Star className="h-3 w-3 fill-current text-gold" aria-hidden />
              {score.label}
            </p>
            <p className="mt-1 text-xl font-semibold">{score.value}</p>
            {score.note ? (
              <p className="truncate text-xs text-muted-foreground">{score.note}</p>
            ) : null}
          </li>
        ))}
      </ul>
    </section>
  );
}
