import { MovieCard, MovieCardSkeleton } from "./MovieCard";
import type { MovieSummary } from "@/lib/tmdb.types";
import { cn } from "@/lib/utils";

export function MovieGrid({
  movies,
  className,
  emptyMessage = "No films matched your filters.",
  mediaType = "movie",
}: {
  movies: MovieSummary[];
  className?: string;
  emptyMessage?: string;
  mediaType?: "movie" | "tv";
}) {
  if (!movies.length) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-12 text-center text-sm text-muted-foreground">
        {emptyMessage}
      </div>
    );
  }

  return (
    <div
      className={cn(
        "grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6",
        className,
      )}
    >
      {movies.map((movie, index) => (
        <MovieCard key={movie.id} movie={movie} mediaType={mediaType} priority={index < 6} />
      ))}
    </div>
  );
}

export function MovieGridSkeleton({ count = 12 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
      {Array.from({ length: count }).map((_, i) => (
        <MovieCardSkeleton key={i} />
      ))}
    </div>
  );
}
