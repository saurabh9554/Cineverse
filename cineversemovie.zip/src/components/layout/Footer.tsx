import { Link } from "@tanstack/react-router";
import { Clapperboard } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-surface/50">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-4 lg:px-8">
        <div className="space-y-3 md:col-span-2">
          <div className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-primary">
              <Clapperboard className="h-4 w-4 text-primary-foreground" aria-hidden />
            </span>
            <span className="font-display text-xl uppercase tracking-wider">CineVerse AI</span>
          </div>
          <p className="max-w-sm text-sm text-muted-foreground">
            A cinematic discovery engine — curated rows, deep metadata, trailers and AI-powered
            recommendations tuned to your taste.
          </p>
        </div>

        <nav className="space-y-3" aria-label="Browse">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-foreground">Browse</h2>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/trending" className="hover:text-foreground">Trending</Link></li>
            <li><Link to="/upcoming" className="hover:text-foreground">Upcoming</Link></li>
            <li><Link to="/top-rated" className="hover:text-foreground">Top rated</Link></li>
            <li><Link to="/genres" className="hover:text-foreground">Genres</Link></li>
          </ul>
        </nav>

        <nav className="space-y-3" aria-label="More">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-foreground">More</h2>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/tv-shows" className="hover:text-foreground">TV shows</Link></li>
            <li><Link to="/series" className="hover:text-foreground">Web series</Link></li>
            <li><Link to="/news" className="hover:text-foreground">News</Link></li>
            <li><Link to="/recommendations" className="hover:text-foreground">AI picks</Link></li>
            <li><Link to="/search" search={{ q: "", page: 1 }} className="hover:text-foreground">Search</Link></li>
            <li><Link to="/profile" className="hover:text-foreground">Your profile</Link></li>
          </ul>
        </nav>
      </div>

      <div className="border-t border-border px-4 py-6 text-center text-xs text-muted-foreground sm:px-6 lg:px-8">
        <address className="not-italic">
          <p className="text-sm font-semibold uppercase tracking-wider text-foreground">
            Saurabh Vishwakarma
          </p>
          <p className="mt-1">Owner · Consultant</p>
          <p>Bengaluru, India</p>
        </address>
        <p className="mt-4">
          © {new Date().getFullYear()} CineVerse AI. Film data provided by TMDB and OMDb. This
          product is not endorsed or certified by TMDB.
        </p>
      </div>
    </footer>
  );
}
